#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

HOME_DIR="$HOME"
ROOT="$HOME_DIR/ADAAD"
STAGING="$ROOT/_home_imports"

mkdir -p "$STAGING"/{repos,env,scripts,archives,external,knowledge,downloads,misc}

move_if_exists() {
  local src="$1"
  local dest_dir="$2"
  if [ -e "$src" ]; then
    echo "  -> $src -> $dest_dir/"
    mv "$src" "$dest_dir/"
  fi
}

cd "$HOME_DIR"

echo "=== Re-homing ADAAD ecosystem into $ROOT ==="
echo "ROOT:    $ROOT"
echo "STAGING: $STAGING"
echo

echo "=== Phase 1: special handling for ADAAD_merged ==="
if [ -d "ADAAD_merged" ]; then
  echo "Copying ADAAD_merged into staging then removing original..."
  mkdir -p "$STAGING/repos/ADAAD_merged"
  cp -a ADAAD_merged/. "$STAGING/repos/ADAAD_merged/"
  rm -rf ADAAD_merged
else
  echo "No ADAAD_merged directory at ~ (or already moved)."
fi
echo

echo "=== Phase 2: big repos / trees ==="
for item in \
  Apon1 Apon1_backend Aponi_frontend \
  ad ad_old_merged \
  agents backups bin data experiments \
  marketplace prism_core quarantine storage \
  old
do
  move_if_exists "$item" "$STAGING/repos"
done
echo

echo "=== Phase 3: env / requirements / setup logs ==="
for pattern in \
  adaad_venv \
  adaad_reqs_light.txt \
  adaad_reqs_termux.txt \
  adaad_reqs_termux.txt.bak \
  adaad_requirements_termux.txt \
  adaad_setup_log_*.txt \
  reqs_light.txt \
  reqs_no_numpy.txt
do
  for f in $pattern; do
    [ -e "$f" ] || continue
    move_if_exists "$f" "$STAGING/env"
  done
done
echo

echo "=== Phase 4: knowledge / reports ==="
for pattern in \
  adaad_knowledge_20251124 \
  adaad_knowledge_20251124.zip \
  adaad_project_report_*.txt \
  adaad_source_report_*.txt
do
  for f in $pattern; do
    [ -e "$f" ] || continue
    move_if_exists "$f" "$STAGING/knowledge"
  done
done
echo

echo "=== Phase 5: archives ==="
move_if_exists "ad_backup_20251119.zip" "$STAGING/archives"
echo

echo "=== Phase 6: external tools / releases ==="
for item in \
  ghubrelease_v0.1.0 \
  ngrok \
  ngrok-v3-stable-linux-arm64.tgz
do
  move_if_exists "$item" "$STAGING/external"
done
echo

echo "=== Phase 7: downloads ==="
move_if_exists "downloads" "$STAGING/downloads"
echo

echo "=== Phase 8: scripts and helpers ==="
for item in \
  adaad_cleanup.sh \
  adaad_coordinator.sh \
  adaad_path_patch.sh \
  adaad_setup.sh \
  adaad_setup.sh.bak \
  adaad_start.sh \
  adaad_start.sh.bak \
  find_aponi_html.sh \
  merge_ad_old.py \
  merge_adaad_variants.py \
  patch_pkg_A.sh \
  setup_adaad_termux_full.sh \
  setup_adaad_termux_safe.sh \
  swap_aponi_html_from_candidates.sh \
  zip_adaad.py \
  organize_and_structure_home_into_ADAAD.sh \
  move_all_adaad_into_ADAAD.sh \
  move_all_adaad_into_ADAAD_v2.sh
do
  move_if_exists "$item" "$STAGING/scripts"
done
echo

echo "=== Phase 9: misc HTML / UI bits ==="
for item in nono.html pic.html; do
  move_if_exists "$item" "$STAGING/misc"
done
echo

echo "=== Done. Home now contains: ==="
ls -a "$HOME_DIR"
echo
echo "=== Staged under: $STAGING ==="
find "$STAGING" -maxdepth 2 -mindepth 1
