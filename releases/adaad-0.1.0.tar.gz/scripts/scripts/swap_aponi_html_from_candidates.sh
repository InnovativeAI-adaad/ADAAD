#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ADAAD_ROOT="$HOME/ADAAD"
STATIC_HTML="${ADAAD_ROOT}/static/aponi_dashboard.html"

# Candidate HTMLs from your listing
CANDIDATES=(
  "/storage/emulated/0/Download/adaad_project/aponi_dashboard.html"
  "/storage/emulated/0/BakUPSADAAD/archive/cleanup-20251111T050308Z/dedup/by_name/aponi_dashboard.html"
)

echo "[SWAP] ADAAD root: ${ADAAD_ROOT}"
echo "[SWAP] Current static HTML: ${STATIC_HTML}"
echo

chosen=""

for cand in "${CANDIDATES[@]}"; do
  if [ -f "$cand" ]; then
    echo "[SWAP] Checking candidate: $cand"
    # Look for an <html> tag to verify it's real HTML, not Python
    if grep -qi "<html" "$cand"; then
      echo "[SWAP] -> Looks like HTML. Selecting this candidate."
      chosen="$cand"
      break
    else
      echo "[SWAP] -> No <html> tag detected, skipping."
    fi
  else
    echo "[SWAP] Candidate not found: $cand"
  fi
done

if [ -z "$chosen" ]; then
  echo "[ERROR] No suitable HTML candidate found. Aborting."
  exit 1
fi

mkdir -p "${ADAAD_ROOT}/backups_html"

timestamp="$(date +%Y%m%d_%H%M%S)"

if [ -f "${STATIC_HTML}" ]; then
  backup="${ADAAD_ROOT}/backups_html/aponi_dashboard_${timestamp}.html"
  echo "[SWAP] Backing up current aponi_dashboard.html to: $backup"
  cp "${STATIC_HTML}" "$backup"
fi

echo "[SWAP] Copying chosen HTML:"
echo "  $chosen"
echo "  -> ${STATIC_HTML}"
cp "$chosen" "$STATIC_HTML"

echo "[SWAP] Done."
echo
echo "Now restart ADAAD and reload the dashboard:"
echo "  cd ${ADAAD_ROOT}"
echo "  source ${HOME}/adaad_venv/bin/activate 2>/dev/null || true"
echo "  python3 goadaad.py"
echo
echo "Open in browser:"
echo "  http://127.0.0.1:8765"
