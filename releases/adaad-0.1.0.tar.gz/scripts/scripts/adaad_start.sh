#!/data/data/com.termux/files/usr/bin/bash
# ADAAD Auto-Launch Script (smart path detection)

# Locate ADAAD
if [ -d /storage/emulated/0/ADAAD ]; then
    cd /storage/emulated/0/ADAAD || exit
elif [ -d ~/storage/shared/ADAAD ]; then
    cd ~/storage/shared/ADAAD || exit
else
    echo "❌ ADAAD directory not found."
    exit 1
fi

# Activate virtual environment
source ~/adaad_venv/bin/activate

# Start orchestrator
echo "🚀 Launching ADAAD..."
python3 main.py
