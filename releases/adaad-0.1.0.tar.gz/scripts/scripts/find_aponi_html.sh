#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

SEARCH_ROOTS=(
  "$HOME/ADAAD"
  "/storage/emulated/0"
)

echo "[INFO] Searching for *aponi*.html under:"
for r in "${SEARCH_ROOTS[@]}"; do
  echo "  - $r"
done
echo

TMP_OUT="$(mktemp)"
trap 'rm -f "$TMP_OUT"' EXIT

for root in "${SEARCH_ROOTS[@]}"; do
  if [ -d "$root" ]; then
    find "$root" -type f -iname '*aponi*.html' -printf '%s %TY-%Tm-%Td %TH:%TM %p\n' >> "$TMP_OUT" 2>/dev/null || true
  fi
done

if [ ! -s "$TMP_OUT" ]; then
  echo "[INFO] No *aponi*.html files found."
  exit 0
fi

echo "[INFO] Candidate Aponi HTML files (largest first):"
echo "  SIZE(bytes)   DATE       TIME   PATH"
echo "---------------------------------------------------------------"
sort -nr "$TMP_OUT" | sed 's/^/  /'
