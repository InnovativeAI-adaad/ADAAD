#!/usr/bin/env bash
# ADAAD path patcher: update ~/ADAAD -> ~/old/ADAAD and full Termux paths

set -u

echo "[ADAAD PATH PATCH] Starting..."

# --- CONFIG: old vs new roots ---

OLD_ROOT_FULL="/data/data/com.termux/files/home/ADAAD"
NEW_ROOT_FULL="/data/data/com.termux/files/home/old/ADAAD"

OLD_ROOT_HOME_TILDE="~/ADAAD"
NEW_ROOT_HOME_TILDE="~/old/ADAAD"

OLD_ROOT_HOME_VAR='$HOME/ADAAD'
NEW_ROOT_HOME_VAR='$HOME/old/ADAAD'

# Directories to scan
SEARCH_DIRS=(
  "$HOME"
)

# Make sure the new root actually exists (safety)
if [ ! -d "$NEW_ROOT_FULL" ]; then
  echo "[ADAAD PATH PATCH] New root '$NEW_ROOT_FULL' does NOT exist."
  echo "[ADAAD PATH PATCH] Move the project first:"
  echo "  mkdir -p ~/old"
  echo "  mv ~/ADAAD ~/old/ADAAD"
  exit 1
fi

echo "[ADAAD PATH PATCH] Searching in:"
for dir in "${SEARCH_DIRS[@]}"; do
  echo "  - $dir"
done

TMP_LIST=$(mktemp)
trap 'rm -f "$TMP_LIST"' EXIT

# ---------------------------------------------------
# Find candidate files containing 'ADAAD'
# ---------------------------------------------------
for dir in "${SEARCH_DIRS[@]}"; do
  [ -d "$dir" ] || continue

  find "$dir" -type f -print0 2>/dev/null | \
  while IFS= read -r -d '' file; do
    case "$file" in
      *.sh|*.bash|*.zsh|*.py|*.txt|*.conf|*.ini|*.service|*.json|*.yaml|*.yml|*.html|*.htm)
        if grep -q "ADAAD" "$file" 2>/dev/null; then
          echo "$file" >> "$TMP_LIST"
        fi
        ;;
      *)
        ;;
    esac
  done
done

sort -u "$TMP_LIST" -o "$TMP_LIST" 2>/dev/null || true

COUNT=$(wc -l < "$TMP_LIST" 2>/dev/null || echo 0)
echo "[ADAAD PATH PATCH] Files to inspect: $COUNT"

if [ "$COUNT" -eq 0 ]; then
  echo "[ADAAD PATH PATCH] No files found containing 'ADAAD'. Nothing to patch."
  exit 0
fi

# ---------------------------------------------------
# Apply in-place replacements with .bak backups
# ---------------------------------------------------
PATCHED=0

while read -r file; do
  [ -f "$file" ] || continue

  sed -i.bak \
    -e "s|$OLD_ROOT_FULL|$NEW_ROOT_FULL|g" \
    -e "s|$OLD_ROOT_HOME_TILDE|$NEW_ROOT_HOME_TILDE|g" \
    -e "s|$OLD_ROOT_HOME_VAR|$NEW_ROOT_HOME_VAR|g" \
    "$file" || true

  PATCHED=$((PATCHED + 1))
done < "$TMP_LIST"

echo "[ADAAD PATH PATCH] Patched $PATCHED files (backups: *.bak)."
echo "[ADAAD PATH PATCH] Done."
