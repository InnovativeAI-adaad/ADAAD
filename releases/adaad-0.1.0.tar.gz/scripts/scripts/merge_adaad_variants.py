#!/usr/bin/env python3
import os
import sys
import json
import shutil

# Three ADAAD variants to merge
SRC_ROOTS = [
    os.path.expanduser('~/old/ADAAD'),
    os.path.expanduser('~/ad/ADAAD'),
    os.path.expanduser('~/ADAAD'),
]

DEST_ROOT = os.path.expanduser('~/ADAAD_merged')

# Directories we consider non-impactful (caches, build output, etc.)
SKIP_DIR_NAMES = {
    '__pycache__',
    '.git',
    '.idea',
    '.vscode',
    '.mypy_cache',
    '.pytest_cache',
    '.ruff_cache',
    '.cache',
    'build',
    'dist',
    '.venv',
    'venv',
    'adaad_venv',
    '.eggs',
    '.gradle',
    'node_modules',
}

# Files we consider non-impactful
SKIP_FILE_NAMES = {
    '.DS_Store',
    'Thumbs.db',
}

SKIP_FILE_SUFFIXES = {
    '.pyc',
    '.pyo',
    '.pyd',
    '.tmp',
    '.swp',
    '.swo',
}


def is_skipped_dir(name: str) -> bool:
    return name in SKIP_DIR_NAMES


def is_skipped_file(name: str) -> bool:
    if name in SKIP_FILE_NAMES:
        return True
    return any(name.endswith(suf) for suf in SKIP_FILE_SUFFIXES)


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def scan_sources():
    """
    Build a mapping: rel_path -> list of candidates
    Each candidate: {src_root, full, size, mtime}
    """
    mapping = {}
    for src_root in SRC_ROOTS:
        if not os.path.isdir(src_root):
            print(f"[WARN] Source root missing: {src_root}", file=sys.stderr)
            continue

        for dirpath, dirnames, filenames in os.walk(src_root):
            # prune junk dirs
            dirnames[:] = [d for d in dirnames if not is_skipped_dir(d)]

            rel_dir = os.path.relpath(dirpath, src_root)
            if rel_dir == '.':
                rel_dir = ''

            for fname in filenames:
                if is_skipped_file(fname):
                    continue

                full = os.path.join(dirpath, fname)
                try:
                    st = os.stat(full)
                except OSError:
                    print(f"[WARN] Cannot stat {full}", file=sys.stderr)
                    continue

                rel_path = os.path.join(rel_dir, fname) if rel_dir else fname
                mapping.setdefault(rel_path, []).append({
                    'src_root': src_root,
                    'full': full,
                    'size': st.st_size,
                    'mtime': st.st_mtime,
                })

    return mapping


def choose_best(candidates):
    """
    Choose the best candidate among duplicates:
    - prefer larger size
    - if tie, prefer newer mtime
    """
    best = None
    for c in candidates:
        if best is None:
            best = c
            continue
        if c['size'] > best['size']:
            best = c
        elif c['size'] == best['size'] and c['mtime'] > best['mtime']:
            best = c
    return best


def merge():
    ensure_dir(DEST_ROOT)

    mapping = scan_sources()
    total_files = len(mapping)
    duplicates = 0

    report = {
        'src_roots': SRC_ROOTS,
        'dest_root': DEST_ROOT,
        'total_paths': total_files,
        'decisions': [],
    }

    for rel_path, candidates in sorted(mapping.items()):
        if len(candidates) > 1:
            duplicates += 1

        best = choose_best(candidates)
        dest_full = os.path.join(DEST_ROOT, rel_path)
        dest_dir = os.path.dirname(dest_full)
        ensure_dir(dest_dir)

        try:
            shutil.copy2(best['full'], dest_full)
        except OSError as e:
            print(f"[ERROR] Copy failed {best['full']} -> {dest_full}: {e}", file=sys.stderr)
            continue

        report['decisions'].append({
            'rel_path': rel_path,
            'chosen': {
                'src_root': best['src_root'],
                'full': best['full'],
                'size': best['size'],
                'mtime': best['mtime'],
            },
            'candidates': candidates,
        })

    report['duplicate_paths'] = duplicates

    report_path = os.path.join(DEST_ROOT, 'merge_report.json')
    try:
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2)
    except OSError as e:
        print(f"[WARN] Could not write report: {e}", file=sys.stderr)

    print("Merge complete.")
    print(f"  Source roots : {SRC_ROOTS}")
    print(f"  Dest root    : {DEST_ROOT}")
    print(f"  Total paths  : {total_files}")
    print(f"  Duplicates   : {duplicates}")
    print(f"  Report       : {report_path}")


if __name__ == '__main__':
    merge()
