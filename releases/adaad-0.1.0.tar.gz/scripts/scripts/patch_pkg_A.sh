#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-$HOME/ADAAD}"
cd "$ROOT"

echo "[1/12] Create package skeleton"
mkdir -p adaad
for d in core agents api cognition config execution models plugins providers utils marketplace; do
  [ -d "$d" ] && mkdir -p "adaad/$d" && rsync -a --delete "$d/". "adaad/$d"/
done

echo "[2/12] Add __init__.py files"
find adaad -type d -exec sh -c 'for p in "$@"; do [ -f "$p/__init__.py" ] || printf "" > "$p/__init__.py"; done' _ {} +

echo "[3/12] Keep top-level entry points but make them import adaad.*"
# Ensure we still have these entrypoints at repo root
for f in main.py aponi_dashboard.py goadaad.py; do
  [ -f "$f" ] && cp -f "$f" "$f.bak.pkgA"
done

echo "[4/12] Replace import paths across codebase (safe regexes)"
# Common agent/core fixes
apply_sed () { LANG=C LC_ALL=C sed -i "$1" "$2"; }

# In agents: absolute package imports
find adaad/agents -type f -name "*.py" -print0 | while IFS= read -r -d '' f; do
  apply_sed 's@from[ ]\+base_agent[ ]\+import@from adaad.agents.base_agent import@g' "$f" || true
  apply_sed 's@import[ ]\+base_agent@from adaad.agents import base_agent@g' "$f" || true
  apply_sed 's@from[ ]\+agent_template[ ]\+import@from adaad.agents.agent_template import@g' "$f" || true
  apply_sed 's@from[ ]\+core\.@from adaad.core.@g' "$f" || true
  apply_sed 's@from[ ]\+utils\.@from adaad.utils.@g' "$f" || true
done

# In whole package: fix top-level direct "core." and "agents." imports
find adaad -type f -name "*.py" -print0 | while IFS= read -r -d '' f; do
  apply_sed 's@from[ ]\+core\.@from adaad.core.@g' "$f" || true
  apply_sed 's@import[ ]\+core\.@import adaad.core.@g' "$f" || true
  apply_sed 's@from[ ]\+agents\.@from adaad.agents.@g' "$f" || true
  apply_sed 's@import[ ]\+agents\.@import adaad.agents.@g' "$f" || true
done

echo "[5/12] Write robust EventBus (exports BUS)"
cat > adaad/core/eventbus.py << 'PY'
from __future__ import annotations
import json, time, threading
from pathlib import Path
from typing import Any, Callable, Dict, List

ROOT = Path(__file__).resolve().parents[2]
LOGS = ROOT / "logs"
LOGS.mkdir(parents=True, exist_ok=True)
EVENT_LOG = LOGS / "eventbus.log"

class EventBus:
    def __init__(self) -> None:
        self._subs: Dict[str, List[Callable[[str, Any], None]]] = {}
        self._lock = threading.RLock()

    def _log(self, msg: str) -> None:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with EVENT_LOG.open("a", encoding="utf-8") as f:
            f.write(f"{ts} | {msg}\n")

    def publish(self, topic: str, data: Any) -> None:
        with self._lock:
            subs = list(self._subs.get(topic, []))
        for fn in subs:
            try:
                fn(topic, data)
            except Exception as e:
                self._log(f"handler error: {e!r}")
        try:
            payload = json.dumps(data, ensure_ascii=False)[:300]
        except Exception:
            payload = "<unserializable>"
        self._log(f"pub | {topic} | {payload}")

    def subscribe(self, topic: str, handler: Callable[[str, Any], None]) -> None:
        with self._lock:
            self._subs.setdefault(topic, []).append(handler)
        self._log(f"sub | {topic}")

    def topics(self) -> List[str]:
        with self._lock:
            return sorted(self._subs.keys())

BUS = EventBus()
PY

echo "[6/12] WebSocket bridge for EventBus"
mkdir -p adaad/api
cat > adaad/api/eventbus_ws.py << 'PY'
#!/usr/bin/env python3
import argparse, asyncio, json
from websockets.server import serve
from adaad.core.eventbus import BUS

CLIENTS = set()

async def ws_handler(ws):
    CLIENTS.add(ws)
    try:
        async for msg in ws:
            try:
                obj = json.loads(msg)
                topic = obj.get("topic", "broadcast")
                data = obj.get("data", {})
                BUS.publish(topic, data)
            except Exception:
                # ignore bad payloads
                pass
    finally:
        CLIENTS.discard(ws)

def forward_to_ws(topic, data):
    msg = json.dumps({"topic": topic, "data": data})
    # fire-and-forget to avoid blocking BUS handlers
    for ws in list(CLIENTS):
        try:
            asyncio.create_task(ws.send(msg))
        except Exception:
            pass

BUS.subscribe("broadcast", forward_to_ws)

async def main(host: str, port: int):
    async with serve(ws_handler, host, port):
        print(f"EventBus WS running on ws://{host}:{port}/")
        await asyncio.Future()

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8787)
    args = ap.parse_args()
    asyncio.run(main(args.host, args.port))
PY
chmod +x adaad/api/eventbus_ws.py

echo "[7/12] CLI tool for the bus"
cat > adaad/api/bus_cli.py << 'PY'
#!/usr/bin/env python3
import argparse, json, time
from adaad.core.eventbus import BUS

ap = argparse.ArgumentParser(prog="bus")
sub = ap.add_subparsers(dest="cmd", required=True)

p_pub = sub.add_parser("publish")
p_pub.add_argument("--topic", required=True)
p_pub.add_argument("--data", default="{}")

sub.add_parser("topics")
sub.add_parser("ping")

def main():
    a = ap.parse_args()
    if a.cmd == "publish":
        payload = json.loads(a.data)
        BUS.publish(a.topic, payload)
        print(f"published to {a.topic}: {payload}")
    elif a.cmd == "topics":
        for t in BUS.topics():
            print(t)
    elif a.cmd == "ping":
        BUS.publish("ping", {"ts": time.time()})
        print("ping sent")

if __name__ == "__main__":
    main()
PY
chmod +x adaad/api/bus_cli.py

echo "[8/12] Fix George + warm_fallback template"
# George shim for legacy imports
cat > adaad/agents/george.py << 'PY'
# george.py shim -> agent_george.GeorgeMetaAgent for legacy references
from adaad.agents.agent_george import GeorgeMetaAgent as George
PY

# Harden warm fallback template written/used by George
cat > adaad/agents/agent_warm_fallback_template.py << 'PY'
from __future__ import annotations
from typing import Any, Dict
from adaad.agents.base_agent import BaseAgent

class WarmFallback(BaseAgent):
    role = "default"
    version = "1.0"

    def describe(self) -> str:
        return "WarmFallback baseline agent."

    def act(self, task: str, context: Dict[str, Any] | None = None) -> Dict[str, Any]:
        ctx = dict(context or {})
        return {"ok": True, "output": f"[WarmFallback] handled: {task}", "meta": {"ctx_keys": list(ctx.keys())}}

    def evaluate(self) -> Dict[str, float]:
        return {"fitness": 0.987, "ok": True}
PY

# If agent_george exists in package copy, ensure import style is package-absolute and future-import at top
if [ -f adaad/agents/agent_george.py ]; then
  apply_sed '1h;1!H;$!d; s@from __future__.*@from __future__ import annotations\n@g' adaad/agents/agent_george.py || true
  apply_sed 's@from \.base_agent import BaseAgent@from adaad.agents.base_agent import BaseAgent@g' adaad/agents/agent_george.py || true
  apply_sed 's@from base_agent import BaseAgent@from adaad.agents.base_agent import BaseAgent@g' adaad/agents/agent_george.py || true
fi

echo "[9/12] Make Aponi dashboard auto-detect bus port (fallback 8787)"
# If the UI references a fixed ws://127.0.0.1:8765, rewrite it to use window.ADAAD_BUS or default 8787
if [ -f aponi_dashboard.html ]; then
  cp -f aponi_dashboard.html aponi_dashboard.html.bak.pkgA
  awk '
    BEGIN{patched=0}
    {print}
    END{
      if(!patched){
        print "<script>window.ADAAD_BUS = window.ADAAD_BUS || (location.protocol===\"https:\"?\"wss\":\"ws\") + \"://\" + location.hostname + \":\" + (window.ADAAD_BUS_PORT||8787) + \"/\";</script>";
      }
    }' aponi_dashboard.html > aponi_dashboard.html.tmp && mv aponi_dashboard.html.tmp aponi_dashboard.html
fi

echo "[10/12] Update goadaad.py to manage bus and package"
cat > goadaad.py << 'PY'
#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, signal, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

# Ensure "adaad" package is importable by all subprocesses
env = os.environ.copy()
env["PYTHONUNBUFFERED"] = "1"

def start(proc_name: str, argv: list[str]) -> subprocess.Popen:
    return subprocess.Popen(argv, cwd=str(ROOT), env=env)

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(ROOT))
    ap.add_argument("--aponi-port", type=int, default=8765)
    ap.add_argument("--aponi-host", default="0.0.0.0")
    ap.add_argument("--bus-port", type=int, default=8787)
    ap.add_argument("--bus-host", default="0.0.0.0")
    ap.add_argument("--no-aponi", action="store_true")
    ap.add_argument("--no-dream", action="store_true")
    ap.add_argument("--no-bus", action="store_true")
    ap.add_argument("--status-every", type=int, default=5)
    ap.add_argument("--single-instance-off", action="store_true")
    return ap.parse_args()

def main():
    args = parse_args()
    procs = {}

    def spawn_all():
        if "adaad" not in procs or procs["adaad"].poll() is not None:
            procs["adaad"] = start("adaad", [sys.executable, "main.py"])
            print("[goadaad] [adaad] starting: python3 main.py")
        if not args.no_aponi and ("aponi" not in procs or procs["aponi"].poll() is not None):
            procs["aponi"] = start("aponi", [sys.executable, "aponi_dashboard.py", "serve",
                                             "--base-path", args.root, "--host", args.aponi_host, "--port", str(args.aponi_port)])
            print(f"[goadaad] [aponi] starting: python3 aponi_dashboard.py serve --host {args.aponi_host} --port {args.aponi_port}")
        if not args.no_bus and ("bus" not in procs or procs["bus"].poll() is not None):
            procs["bus"] = start("bus", [sys.executable, "-m", "adaad.api.eventbus_ws",
                                         "--host", args.bus_host, "--port", str(args.bus_port)])
            print(f"[goadaad] [bus] starting: python3 -m adaad.api.eventbus_ws --host {args.bus_host} --port {args.bus_port}")
        if not args.no_dream and ("dream" not in procs or procs["dream"].poll() is not None):
            procs["dream"] = start("dream", [sys.executable, "adaad/core/dream_mode.py"])
            print("[goadaad] [dream] starting: python3 adaad/core/dream_mode.py")

    def stop_all():
        for k, p in procs.items():
            try:
                p.terminate()
            except Exception:
                pass
        time.sleep(0.5)
        for k, p in procs.items():
            try:
                p.kill()
            except Exception:
                pass

    def on_sigint(signum, frame):
        print("[goadaad] Stopping services...")
        stop_all()
        print("[goadaad] Unified Launcher exited cleanly.")
        sys.exit(0)

    signal.signal(signal.SIGINT, on_sigint)
    signal.signal(signal.SIGTERM, on_sigint)

    spawn_all()
    last = time.time()

    # simple supervision loop
    while True:
        time.sleep(1)
        # respawn crashed ones
        spawn_all()
        if time.time() - last >= args.status_every:
            status = ", ".join(f"{k}:{'up' if p.poll() is None else 'down'}" for k, p in procs.items())
            print(f"[goadaad] Status: {status}")
            last = time.time()

if __name__ == "__main__":
    main()
PY

echo "[11/12] Make bus callable via -m and ensure PYTHONPATH is correct"
# Nothing to do; we placed module under adaad/api/eventbus_ws.py which is importable with -m

echo "[12/12] Final advice + quick self-check"
python3 - << 'PY'
import importlib, sys
sys.path.insert(0, ".")
m = importlib.import_module("adaad.core.eventbus")
assert hasattr(m, "BUS"), "BUS not found in adaad.core.eventbus"
print("[check] adaad.core.eventbus: OK")
PY

echo
echo "Patch A complete."
echo
echo "Run:"
echo "  cd \"$ROOT\""
echo "  pkill -9 -f python3 || true"
echo "  python3 goadaad.py --no-dream --bus-port 9000"
echo
echo "Aponi will still run on :8765; the dashboard auto-detects EventBus ws://<host>:8787 unless you override."
echo "Use CLI:  python3 -m adaad.api.bus_cli topics  |  python3 -m adaad.api.bus_cli publish --topic broadcast --data '{\"msg\":\"hi\"}'"
