#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

HOME_DIR="$HOME"
ROOT="$HOME_DIR/ADAAD"
STAGING="$ROOT/_home_imports"

mkdir -p "$STAGING"/{repos,env,scripts,archives,external,knowledge,downloads,misc}

move_if_exists() {
  local src="$1"
  local dest_dir="$2"
  if [ -e "$src" ]; then
    echo "  -> $src -> $dest_dir/"
    mv "$src" "$dest_dir/"
  fi
}

cd "$HOME_DIR"

echo "=== Re-homing ADAAD ecosystem into \$ROOT ==="
echo "ROOT:    $ROOT"
echo "STAGING: $STAGING"

# 1) Big repos / trees (excluding ADAAD itself)
for item in \
  Apon1 Apon1_backend Aponi_frontend \
  ad ad_old_merged \
  agents backups bin data experiments \
  marketplace prism_core quarantine storage \
  old
do
  move_if_exists "$item" "$STAGING/repos"
done

# 2) Special handling for ADAAD_merged to avoid 'subdirectory of itself' issues
if [ -d "ADAAD_merged" ]; then
  echo "Archiving ADAAD_merged into staging..."
  mkdir -p "$STAGING/repos"
  tar -cf "$STAGING/repos/ADAAD_merged.tar" ADAAD_merged
  mkdir -p "$STAGING/repos/ADAAD_merged"
  tar -xf "$STAGING/repos/ADAAD_merged.tar" -C "$STAGING/repos/ADAAD_merged" --strip-components=1
  rm -rf ADAAD_merged "$STAGING/repos/ADAAD_merged.tar"
fi

# 3) Env / requirements / logs
for pattern in \
  adaad_venv \
  adaad_reqs_light.txt \
  adaad_reqs_termux.txt \
  adaad_reqs_termux.txt.bak \
  adaad_requirements_termux.txt \
  adaad_setup_log_*.txt \
  reqs_light.txt \
  reqs_no_numpy.txt
do
  for f in $pattern 2>/dev/null; do
    move_if_exists "$f" "$STAGING/env"
  done
done

# 4) Knowledge / reports
for pattern in \
  adaad_knowledge_20251124 \
  adaad_knowledge_20251124.zip \
  adaad_project_report_*.txt \
  adaad_source_report_*.txt
do
  for f in $pattern 2>/dev/null; do
    move_if_exists "$f" "$STAGING/knowledge"
  done
done

# 5) Archives
move_if_exists "ad_backup_20251119.zip" "$STAGING/archives"

# 6) External tools / releases
for item in \
  ghubrelease_v0.1.0 \
  ngrok \
  ngrok-v3-stable-linux-arm64.tgz
do
  move_if_exists "$item" "$STAGING/external"
done

# 7) Downloads
move_if_exists "downloads" "$STAGING/downloads"

# 8) Scripts and helpers (including old mover)
for item in \
  adaad_cleanup.sh \
  adaad_coordinator.sh \
  adaad_path_patch.sh \
  adaad_setup.sh \
  adaad_setup.sh.bak \
  adaad_start.sh \
  adaad_start.sh.bak \
  find_aponi_html.sh \
  merge_ad_old.py \
  merge_adaad_variants.py \
  patch_pkg_A.sh \
  setup_adaad_termux_full.sh \
  setup_adaad_termux_safe.sh \
  swap_aponi_html_from_candidates.sh \
  zip_adaad.py \
  move_all_adaad_into_ADAAD.sh
do
  move_if_exists "$item" "$STAGING/scripts"
done

# 9) Misc HTML etc.
for item in nono.html pic.html; do
  move_if_exists "$item" "$STAGING/misc"
done

echo
echo "=== Done. Home now contains: ==="
ls -a "$HOME_DIR"
echo
echo "=== Staged under: $STAGING ==="
find "$STAGING" -maxdepth 2 -mindepth 1
