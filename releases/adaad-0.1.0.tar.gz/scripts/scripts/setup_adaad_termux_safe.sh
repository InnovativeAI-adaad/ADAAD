#!/usr/bin/env bash
# wrapper: run setup_adaad_termux_full.sh with SKIP_RUST default=1 (skip heavy builds)
set -euo pipefail
SCRIPT="./setup_adaad_termux_full.sh"
if [ ! -x "$SCRIPT" ]; then
  echo "Warning: $SCRIPT not found or not executable. Trying to make it executable..."
  chmod +x "$SCRIPT" || true
fi
export SKIP_RUST="${SKIP_RUST:-1}"
echo "Running $SCRIPT with SKIP_RUST=${SKIP_RUST}"
# forward all args
"$SCRIPT" "$@"
