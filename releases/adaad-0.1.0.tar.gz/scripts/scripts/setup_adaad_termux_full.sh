#!/usr/bin/env bash
# setup_adaad_termux_full.sh
# Robust, fail-safe Termux setup for ADAAD (v1)
# - creates venv at ./adaad_venv
# - upgrades pip toolchain
# - installs many commonly-needed packages (web, ml, hh, openai, transformers, hf-hub, etc)
# - falls back on safer pip flags if installs fail
# - creates adaad_activate.sh helper and RC aliases
# - attempts to install Termux packages (clang, make, rust, openssl-dev, libffi-dev) if pkg exists
#
# Recommended run from ADAAD root (/storage/emulated/0/ADAAD)
# Use: SKIP_ML=1 ./setup_adaad_termux_full.sh  (if you want to skip heavy ML installs)
set -euo pipefail
IFS=$'\n\t'

### CONFIG
ROOT="$(pwd)"
TS="$(date +%Y%m%dT%H%M%S)"
VENV_DIR="${ROOT}/adaad_venv"
ACT_SH="${ROOT}/adaad_activate.sh"
LOG="${ROOT}/adaad_setup_log_${TS}.txt"
BACKUP_SUFFIX=".bak.${TS}"
SKIP_ML="${SKIP_ML:-0}"   # set to 1 to skip heavy ML stack
FORCE_REINSTALL="${FORCE_REINSTALL:-0}" # set to 1 to force reinstall pip packages
PIP_TIMEOUT=120
PIP_RETRIES=2
PIP_RETRY_SLEEP=6

echo "=== ADAAD Termux full setup ===" | tee "$LOG"
echo "Root: $ROOT" | tee -a "$LOG"
echo "Venv: $VENV_DIR" | tee -a "$LOG"
echo "Skip ML: $SKIP_ML" | tee -a "$LOG"
echo "" | tee -a "$LOG"

# Helper functions
log() { echo "[$(date +'%H:%M:%S')] $*" | tee -a "$LOG"; }
err() { echo "[$(date +'%H:%M:%S')] ERROR: $*" | tee -a "$LOG" >&2; }

check_cmd() {
  command -v "$1" >/dev/null 2>&1
}

safe_cp_backup() {
  local f="$1"
  if [ -f "$f" ]; then
    cp -a "$f" "${f}${BACKUP_SUFFIX}" || true
    log "Backed up $f -> ${f}${BACKUP_SUFFIX}"
  fi
}

# 1) detect python & termux environment
PY_BIN="$(command -v python3 || command -v python || true)"
if [ -z "$PY_BIN" ]; then
  err "python3 not found in PATH. Install Termux python: pkg install python"
  exit 2
fi
log "Using interpreter: $PY_BIN"

if check_cmd pkg; then
  TERMUX=yes
  log "Detected Termux environment."
else
  TERMUX=no
  log "Termux package manager not detected (pkg). Script will attempt best-effort installation via pip only."
fi

# ensure current directory is ADAAD root — set ADAAD_ROOT env
export ADAAD_ROOT="$ROOT"

# 2) Try to install essential Termux packages (best-effort; skip if no pkg)
if [ "$TERMUX" = "yes" ]; then
  log "Installing Termux build tools and common libs (clang, make, openssl-dev, libffi-dev, git, rust, pkg-config)..."
  # Try to be non-destructive; continue on errors
  pkg update -y 2>&1 | tee -a "$LOG" || true
  pkg install -y git clang make openssl-dev libffi-dev pkg-config python python-dev coreutils >/dev/null 2>&1 || true
  # attempt to install rust (for pip packages that need rust)
  pkg install -y rust >/dev/null 2>&1 || true
  pkg install -y build-essential >/dev/null 2>&1 || true
  log "Termux packages installation attempted (check above for failures)."
else
  log "Skipping Termux package install because pkg not found."
fi

# 3) Create venv
if [ -d "$VENV_DIR" ]; then
  log "Venv already exists at $VENV_DIR — backing it up."
  safe_cp_backup "$VENV_DIR"
fi

log "Creating virtualenv at $VENV_DIR..."
"$PY_BIN" -m venv "$VENV_DIR"
PY_IN_VENV="${VENV_DIR}/bin/python"
PIP_IN_VENV="${VENV_DIR}/bin/pip"

# ensure pip exists, upgrade pip/setuptools/wheel
log "Bootstrapping pip in venv..."
"$PY_IN_VENV" -m ensurepip --upgrade >/dev/null 2>&1 || true
log "Upgrading pip, setuptools, wheel..."
"$PIP_IN_VENV" install --upgrade pip setuptools wheel >/dev/null 2>&1 || "$PIP_IN_VENV" install --upgrade pip setuptools wheel || true

# 4) system-wide helper: install gh (GitHub CLI) if possible
if [ "$TERMUX" = "yes" ]; then
  if ! check_cmd gh; then
    log "Attempting to install GitHub CLI (gh) via apt/pkg..."
    pkg install -y gh >/dev/null 2>&1 || log "gh install via pkg failed (not critical)."
  fi
fi

# 5) Primary package lists (split into categories)
CORE_PYPI=(
  # core utils & web
  flask fastapi uvicorn[standard] starlette requests aiohttp jinja2 aiofiles python-multipart websockets
  # data & persistence
  pyyaml tinydb sqlalchemy
  # dev / utils
  gitpython rich tqdm humanize
  # code tooling
  black isort astor
  # clients
  openai google-generativeai huggingface_hub
  # hf-friendly
  transformers diffusers accelerate safetensors
  # LLM support
  tiktoken sentence-transformers
  # optional helpful
  python-dotenv watchdog
)

# ML-specific heavy packages (may fail on Android; we handle gracefully)
ML_PYPI=(
  torch torchvision torchaudio
  bitsandbytes safetensors
)

# scoring / Adaad-specific extras
ADAAD_EXTRAS=(
  psutil
  boto3
  requests-toolbelt
)

# CLI / developer extras
DEV_EXTRAS=(
  pre-commit
  pyflakes flake8
)

# aggregate but keep order: core, adaad extras, dev extras, then ML (optional)
ALL_PYPI=("${CORE_PYPI[@]}" "${ADAAD_EXTRAS[@]}" "${DEV_EXTRAS[@]}")
if [ "$SKIP_ML" != "1" ]; then
  ALL_PYPI+=("${ML_PYPI[@]}")
fi

# 6) pip install with retries and graceful fallbacks
pip_install_with_retry() {
  local pkg="$1"
  local success=0
  local attempt=0
  while [ $attempt -le $PIP_RETRIES ]; do
    attempt=$((attempt+1))
    log "Installing: $pkg (attempt $attempt/$PIP_RETRIES) ..."
    if [ "$FORCE_REINSTALL" = "1" ]; then
      "$PIP_IN_VENV" install --upgrade --force-reinstall --no-cache-dir --timeout $PIP_TIMEOUT "$pkg" && success=1 || success=0
    else
      "$PIP_IN_VENV" install --upgrade --no-cache-dir --timeout $PIP_TIMEOUT "$pkg" && success=1 || success=0
    fi
    if [ $success -eq 1 ]; then
      log "Installed $pkg successfully."
      return 0
    else
      log "Failed to install $pkg on attempt $attempt."
      sleep $PIP_RETRY_SLEEP
    fi
  done

  # fallback strategies if pip install entire spec failed
  log "Applying fallbacks for $pkg ..."
  # 1) try prefer-binary
  if "$PIP_IN_VENV" install --prefer-binary --no-cache-dir --timeout $PIP_TIMEOUT "$pkg"; then
    log "Fallback prefer-binary succeeded for $pkg"
    return 0
  fi
  # 2) try no-binary for problematic packages (force source-> may fail)
  if "$PIP_IN_VENV" install --no-binary :all: --no-cache-dir --timeout $PIP_TIMEOUT "$pkg"; then
    log "Fallback no-binary succeeded for $pkg"
    return 0
  fi
  # 3) special-case: try cpu-only torch wheel index (some devices)
  if [[ "$pkg" =~ ^torch($|[[:space:]]|/) ]]; then
    log "Trying PyTorch CPU wheels fallback for torch..."
    if "$PIP_IN_VENV" install --no-cache-dir --timeout $PIP_TIMEOUT -f https://download.pytorch.org/whl/cpu torch; then
      log "Torch installed via CPU wheel fallback."
      return 0
    fi
  fi

  err "All pip install attempts failed for $pkg"
  return 1
}

# 7) Install packages in a loop, skip ones we know may be heavy if SKIP_ML=1
log "Starting pip installation of curated package list. This may take a while."
failed_pkgs=()
for pkg in "${ALL_PYPI[@]}"; do
  # if SKIP_ML and pkg is in ML list, skip
  if [ "$SKIP_ML" = "1" ]; then
    case " ${ML_PYPI[*]} " in *" $pkg "*) log "Skipping heavy ML pkg $pkg due to SKIP_ML=1"; continue ;; esac
  fi
  if ! pip_install_with_retry "$pkg"; then
    failed_pkgs+=("$pkg")
  fi
done

# 8) Post-install: try to install ADAAD local requirements (if exist)
if [ -f "$ROOT/requirements.txt" ]; then
  log "Installing project requirements.txt..."
  if ! "$PIP_IN_VENV" install -r "$ROOT/requirements.txt"; then
    err "requirements.txt failed to install fully; check log"
  fi
fi
if [ -f "$ROOT/core/requirements.txt" ]; then
  log "Installing core/requirements.txt..."
  if ! "$PIP_IN_VENV" install -r "$ROOT/core/requirements.txt"; then
    err "core/requirements.txt failed to install fully; check log"
  fi
fi

# 9) Try to set up GitHub CLI and HF login helpers (best-effort)
if check_cmd gh; then
  log "GitHub CLI present."
else
  if [ "$TERMUX" = "yes" ]; then
    log "Attempted to install gh earlier; if you want GH CLI, install it via 'pkg install gh' or via gh releases."
  fi
fi

# 10) Create adaad_activate.sh helper
cat > "$ACT_SH" <<'SH'
#!/usr/bin/env bash
# ADAAD venv activation helper
export ADAAD_ROOT="${PWD}"
VENV="${ADAAD_ROOT}/adaad_venv"
if [ -f "${VENV}/bin/activate" ]; then
  # shellcheck disable=SC1090
  source "${VENV}/bin/activate"
  export ADAAD_ROOT
  echo "Activated ADAAD venv at ${VENV}"
else
  echo "No ADAAD venv found at ${VENV}. Run setup script from ADAAD root."
fi
SH
chmod +x "$ACT_SH"
log "Wrote activation helper $ACT_SH"

# 11) Add alias to shell rc (non-duplicating)
RC_FILE="${HOME}/.bashrc"
if [ -f "${RC_FILE}" ]; then
  grep -q "adaad_activate" "$RC_FILE" || cat >> "$RC_FILE" <<'RC'
# ADAAD venv helper
alias adaad-activate='. "${PWD}/adaad_activate.sh"'
RC
  log "Appended adaad-activate alias to ${RC_FILE}"
else
  # try ~/.profile
  RC_FILE="${HOME}/.profile"
  if [ -f "${RC_FILE}" ]; then
    grep -q "adaad_activate" "$RC_FILE" || cat >> "$RC_FILE" <<'RC'
# ADAAD venv helper
alias adaad-activate='. "${PWD}/adaad_activate.sh"'
RC
    log "Appended adaad-activate alias to ${RC_FILE}"
  else
    log "No shell RC file found to append alias; run . ${ACT_SH} manually to activate venv."
  fi
fi

# 12) Try to stop common Aponi processes (safe)
if [ -d "${ROOT}/pids" ]; then
  for f in "${ROOT}/pids"/*; do
    [ -f "$f" ] || continue
    pid=$(cat "$f" 2>/dev/null || true)
    if [ -n "$pid" ] && ps -p "$pid" >/dev/null 2>&1; then
      log "Stopping stale process PID $pid from $f"
      kill "$pid" 2>/dev/null || kill -9 "$pid" 2>/dev/null || true
    fi
  done
fi

# 13) Report summary and run quick smoke tests
log "Setup complete. Summary:"
log "VENV: $VENV_DIR"
log "Activate: source $ACT_SH"
if [ ${#failed_pkgs[@]} -ne 0 ]; then
  log "WARNING: The following packages failed to install: ${failed_pkgs[*]}"
  log "You can attempt to re-run pip install for these individually after installing Termux build tools."
else
  log "All pip packages installed successfully (or quiet fallbacks used)."
fi

log "Running quick smoke tests (inside venv) — errors are expected for heavy packages on Android; results will be logged."

# quick smoke function
smoke_test() {
  "$PY_IN_VENV" - <<PYTEST 2>&1 | tee -a "$LOG"
import sys
names = ["flask","fastapi","openai","huggingface_hub","transformers","psutil"]
for n in names:
    try:
        __import__(n)
        print("OK:", n)
    except Exception as e:
        print("FAIL:", n, "->", e)
print("python:", sys.version)
PYTEST
}

smoke_test

log "If any important packages failed (psutil, huggingface_hub, openai, transformers), copy the last lines from the log $LOG and paste here so I can help."

log "You can now activate the venv with:"
log "  source $ACT_SH"
log "Then run:"
log "  python3 core/beast_mode_loop.py --dry-run"
log "  python3 Aponi/api/aponi_server.py  # start Aponi (ensure port free)"
log ""
log "=== ADAAD setup finished ==="

# End