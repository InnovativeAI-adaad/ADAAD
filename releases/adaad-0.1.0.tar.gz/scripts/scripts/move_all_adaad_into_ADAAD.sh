#!/usr/bin/env bash
set -euo pipefail
shopt -s nullglob

ROOT="$HOME/ADAAD"
IMPORT="$ROOT/_home_imports"

echo "=== Moving ADAAD-related items into $ROOT ==="

# Sanity check
if [ ! -d "$ROOT" ]; then
  echo "ERROR: $ROOT does not exist."
  exit 1
fi

mkdir -p "$IMPORT"/{repos,env,scripts,archives,external,knowledge,misc,downloads}

move_to() {
  local dest="$1"
  shift
  mkdir -p "$dest"
  for path in "$@"; do
    [ -e "$path" ] || continue
    # Never move the canonical ADAAD dir itself
    if [ "$path" = "$ROOT" ]; then
      continue
    fi
    echo "-> $path  ->  $dest/"
    mv "$path" "$dest"/
  done
}

cd "$HOME"

# 1) Repos / project dirs / workspaces
move_to "$IMPORT/repos" \
  "$HOME/ADAAD_merged" \
  "$HOME/Apon1" \
  "$HOME/Apon1_backend" \
  "$HOME/Aponi_frontend" \
  "$HOME/ad" \
  "$HOME/ad_old_merged" \
  "$HOME/marketplace" \
  "$HOME/agents" \
  "$HOME/backups" \
  "$HOME/bin" \
  "$HOME/data" \
  "$HOME/experiments" \
  "$HOME/prism_core" \
  "$HOME/storage" \
  "$HOME/quarantine" \
  "$HOME/dreezy66" \
  "$HOME/old"

# 2) Envs / requirements / logs
move_to "$IMPORT/env" \
  "$HOME/adaad_venv" \
  "$HOME/adaad_reqs_light.txt" \
  "$HOME/adaad_reqs_termux.txt" \
  "$HOME/adaad_reqs_termux.txt.bak" \
  "$HOME/adaad_requirements_termux.txt" \
  "$HOME/reqs_light.txt" \
  "$HOME/reqs_no_numpy.txt" \
  "$HOME/adaad_setup_log_"*.txt

# 3) Scripts and helpers
move_to "$IMPORT/scripts" \
  "$HOME/adaad_setup.sh" \
  "$HOME/adaad_setup.sh.bak" \
  "$HOME/adaad_start.sh" \
  "$HOME/adaad_start.sh.bak" \
  "$HOME/adaad_cleanup.sh" \
  "$HOME/adaad_coordinator.sh" \
  "$HOME/setup_adaad_termux_full.sh" \
  "$HOME/setup_adaad_termux_safe.sh" \
  "$HOME/patch_pkg_A.sh" \
  "$HOME/swap_aponi_html_from_candidates.sh" \
  "$HOME/zip_adaad.py" \
  "$HOME/find_aponi_html.sh" \
  "$HOME/adaad_path_patch.sh" \
  "$HOME/merge_ad_old.py" \
  "$HOME/merge_adaad_variants.py" \
  "$HOME/organize_and_structure_home_into_ADAAD.sh" \
  "$HOME/move_all_adaad_into_ADAAD.sh"

# 4) Archives / backups
move_to "$IMPORT/archives" \
  "$HOME/ad_backup_20251119.zip"

# 5) External binaries / releases
move_to "$IMPORT/external" \
  "$HOME/ngrok" \
  "$HOME/ngrok-v3-stable-linux-arm64.tgz" \
  "$HOME/ghubrelease_v0.1.0"

# 6) Knowledge bundles / reports
move_to "$IMPORT/knowledge" \
  "$HOME/adaad_knowledge_20251124" \
  "$HOME/adaad_knowledge_20251124.zip" \
  "$HOME/adaad_project_report_"*.txt \
  "$HOME/adaad_source_report_"*.txt

# 7) Misc HTML / loose files
move_to "$IMPORT/misc" \
  "$HOME/nono.html" \
  "$HOME/pic.html"

# 8) Downloads (optional: move full downloads dir under ADAAD)
move_to "$IMPORT/downloads" \
  "$HOME/downloads"

echo "=== Done. Check: ls ~ and ls $IMPORT ==="
