#!/data/data/com.termux/files/usr/bin/bash

HOME_DIR="$HOME"
ROOT="$HOME_DIR/ADAAD"
STAGING="$ROOT/_home_imports"

# 1) Make sure ADAAD + staging + subdirs exist
mkdir -p "$ROOT"
mkdir -p "$STAGING"
mkdir -p "$STAGING/archives"
mkdir -p "$STAGING/env"
mkdir -p "$STAGING/knowledge"
mkdir -p "$STAGING/external"
mkdir -p "$STAGING/downloads"
mkdir -p "$STAGING/scripts"
mkdir -p "$STAGING/misc"

move_if_exists() {
  local src="$1"
  local dest_dir="$2"
  if [ -e "$src" ]; then
    echo "  -> $src -> $dest_dir/"
    mv "$src" "$dest_dir/"
  fi
}

cd "$HOME_DIR"

echo "=== Phase 1: archives ==="
move_if_exists "ad_backup_20251119.zip" "$STAGING/archives"
echo

echo "=== Phase 2: env / venv / requirements / setup logs ==="
for item in \
  adaad_venv \
  adaad_reqs_light.txt \
  adaad_reqs_termux.txt \
  adaad_reqs_termux.txt.bak \
  adaad_requirements_termux.txt \
  reqs_light.txt \
  reqs_no_numpy.txt \
  adaad_setup_log_20251016T152823.txt
do
  move_if_exists "$item" "$STAGING/env"
done
echo

echo "=== Phase 3: knowledge / reports ==="
for item in \
  adaad_knowledge_20251124 \
  adaad_knowledge_20251124.zip \
  adaad_project_report_20251119_131437.txt \
  adaad_source_report_20251119_131201.txt
do
  move_if_exists "$item" "$STAGING/knowledge"
done
echo

echo "=== Phase 4: external tools / releases ==="
for item in \
  ghubrelease_v0.1.0 \
  ngrok \
  ngrok-v3-stable-linux-arm64.tgz
do
  move_if_exists "$item" "$STAGING/external"
done
echo

echo "=== Phase 5: downloads ==="
move_if_exists "downloads" "$STAGING/downloads"
echo

echo "=== Phase 6: scripts and helpers ==="
for item in \
  adaad_cleanup.sh \
  adaad_coordinator.sh \
  adaad_path_patch.sh \
  adaad_setup.sh \
  adaad_setup.sh.bak \
  adaad_start.sh \
  adaad_start.sh.bak \
  find_aponi_html.sh \
  merge_ad_old.py \
  merge_adaad_variants.py \
  patch_pkg_A.sh \
  setup_adaad_termux_full.sh \
  setup_adaad_termux_safe.sh \
  swap_aponi_html_from_candidates.sh \
  zip_adaad.py \
  move_all_adaad_into_ADAAD.sh \
  move_all_adaad_into_ADAAD_v2.sh \
  move_all_adaad_into_ADAAD_v3.sh \
  move_all_adaad_into_ADAAD_v4.sh \
  move_all_adaad_into_ADAAD_v5.sh \
  move_all_adaad_into_ADAAD_v6.sh \
  move_all_adaad_into_ADAAD_v7.sh \
  move_all_adaad_into_ADAAD_v8.sh
do
  move_if_exists "$item" "$STAGING/scripts"
done
echo

echo "=== Phase 7: misc HTML / UI bits ==="
for item in \
  nono.html \
  pic.html
do
  move_if_exists "$item" "$STAGING/misc"
done
echo

echo "=== Final state of ~ ==="
ls -a "$HOME_DIR"
echo
echo "=== Contents of staging: $STAGING ==="
find "$STAGING" -maxdepth 3 -mindepth 1

