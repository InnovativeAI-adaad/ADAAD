#!/data/data/com.termux/files/usr/bin/bash
# ADAAD Cleanup & Archive — Termux / Pydroid3 ready
# Usage:
#   bash adaad_cleanup.sh                 - run against discovered ADAAD root
#   bash adaad_cleanup.sh /path/to/ADAAD  - specify root
#   bash adaad_cleanup.sh --dry-run       - simulate actions (no moves)
#   bash adaad_cleanup.sh --help          - show help

set -euo nounset
IFS=$'\n\t'

# --------- CONFIG ---------
DRY_RUN=0
ROOT_ARG=""
DEFAULT_CANDIDATES=( "${ADAAD_ROOT:-}" "/storage/emulated/0/ADAAD" "$HOME/ADAAD" "." )
KEEP_PRIORITY=( "Aponi/api" "Aponi" "static" "" )
TMP_PATTERNS=( "*.tmp" "*.bak*" "*.swp" "*.pyc" "*.pyo" "*~" ".aponi.pid" ".lock" "*.log" )
REPORT_PATTERNS=( "adaad_tree_full.json" "adaad_tree_dump.txt" "adaad_tree_summary.csv" "adaad_tree_dashboard.html" "adaad_structure_report.json" "adaad_core_report.csv" "adaad_tree_*.json" "adaad_tree_*.txt" )
WHITELIST_DIRS=( "core" "agents" "Aponi" "archetypes" "static" "logs" "config" "scaffolds" "templates" "plugins" "sandbox" )
LOG_ROTATE_DAYS=7
# --------------------------

# --------- parse args ----------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY_RUN=1; shift ;;
    --help|-h) echo "Usage: $0 [--dry-run] [root]"; exit 0 ;;
    --) shift; break ;;
    -*) echo "Unknown option: $1"; exit 2 ;;
    *) ROOT_ARG="$1"; shift; break ;;
  esac
done

# build candidate list (ROOT_ARG prioritized)
CANDIDATES=()
if [ -n "$ROOT_ARG" ]; then CANDIDATES+=("$ROOT_ARG"); fi
CANDIDATES+=("${DEFAULT_CANDIDATES[@]}")

# find first existing root
FOUND_ROOT=""
for cand in "${CANDIDATES[@]}"; do
  if [ -z "$cand" ]; then continue; fi
  cand_expanded=$(eval echo "$cand")
  if [ -d "$cand_expanded" ]; then
    FOUND_ROOT="$cand_expanded"
    break
  fi
done

if [ -z "$FOUND_ROOT" ]; then
  echo "ERROR: Could not locate ADAAD root. Tried: ${CANDIDATES[*]}"
  exit 3
fi

ROOT="$(cd "$FOUND_ROOT" && pwd -P)"
echo "ADAAD root: $ROOT"
echo "Dry-run: $([ $DRY_RUN -eq 1 ] && echo YES || echo NO)"

# timestamped archive root
TS=$(date -u +%Y%m%dT%H%M%SZ)
ARCHIVE_ROOT="$ROOT/archive/cleanup-$TS"
MANIFEST="$ARCHIVE_ROOT/manifest.json"
mkdir -p "$ARCHIVE_ROOT/backups" "$ARCHIVE_ROOT/moved_tmp" "$ARCHIVE_ROOT/moved_reports" \
         "$ARCHIVE_ROOT/dedup/sha256" "$ARCHIVE_ROOT/dedup/by_name" "$ARCHIVE_ROOT/logs_rotated" \
         "$ARCHIVE_ROOT/empties" "$ARCHIVE_ROOT/reports"

# lockfile to avoid concurrent runs
LOCKFILE="$ROOT/.adaad_cleanup_lock"
if [ -e "$LOCKFILE" ]; then
  echo "Lockfile exists ($LOCKFILE). Another run might be active. Exiting."
  exit 4
fi
touch "$LOCKFILE"
trap 'rm -f "$LOCKFILE"' EXIT

# helper log
_log() { printf '%s %s\n' "$(date -u +'%Y-%m-%dT%H:%M:%SZ')" "$*"; }

# dry-run wrapper
do_move() {
  src="$1"; dst="$2"
  if [ $DRY_RUN -eq 1 ]; then _log "[DRY-RUN] mv $src -> $dst"; return 0; fi
  mkdir -p "$(dirname "$dst")"
  mv -v "$src" "$dst"
}

do_gzip_move() {
  src="$1"; dst="$2"
  if [ $DRY_RUN -eq 1 ]; then _log "[DRY-RUN] gzip $src -> $dst.gz"; return 0; fi
  mkdir -p "$(dirname "$dst")"
  gzip -c "$src" > "$dst.gz" && rm -f "$src"
}

# 1) Full tar.gz backup
_backup_file="$ARCHIVE_ROOT/backups/adaad-full-backup-$TS.tar.gz"
_log "Creating full backup: $_backup_file (may be large)"
if [ $DRY_RUN -eq 1 ]; then
  _log "[DRY-RUN] tar -czf $_backup_file -C \"$ROOT\" ."
else
  tar --warning=no-file-changed -czf "$_backup_file" -C "$ROOT" . 2> "$ARCHIVE_ROOT/tar_warnings.txt" || _log "tar returned warnings (see tar_warnings.txt)"
fi

# 2) Move temp/cache/lock/log files
_log "Archiving temp/cache/lock/log files..."
for pat in "${TMP_PATTERNS[@]}"; do
  while IFS= read -r -d '' f; do
    [[ "$f" == "$ARCHIVE_ROOT"* ]] && continue
    rel="${f#$ROOT/}"
    dst="$ARCHIVE_ROOT/moved_tmp/$rel"
    do_move "$f" "$dst"
  done < <(find "$ROOT" -type f -iname "$pat" -not -path "$ARCHIVE_ROOT/*" -print0 2>/dev/null)
done

# 3) Move large report/dump files
_log "Archiving large reports..."
for pat in "${REPORT_PATTERNS[@]}"; do
  while IFS= read -r -d '' f; do
    [[ "$f" == "$ARCHIVE_ROOT"* ]] && continue
    rel="${f#$ROOT/}"
    dst="$ARCHIVE_ROOT/moved_reports/$rel"
    do_move "$f" "$dst"
  done < <(find "$ROOT" -type f -name "$pat" -not -path "$ARCHIVE_ROOT/*" -print0 2>/dev/null)
done

# 4) Rotate old logs
_log "Rotating logs older than $LOG_ROTATE_DAYS days"
if [ -d "$ROOT/logs" ]; then
  find "$ROOT/logs" -type f -mtime +"$LOG_ROTATE_DAYS" -not -path "$ARCHIVE_ROOT/*" -print0 | while IFS= read -r -d '' lf; do
    rel="${lf#$ROOT/}"
    dst="$ARCHIVE_ROOT/logs_rotated/$rel"
    do_gzip_move "$lf" "$dst"
  done
fi

# 5) Deduplicate by SHA256
_log "Deduplicating identical files (SHA256)..."
export ROOT ARCHIVE_ROOT DRY_RUN
python3 - <<'PY'
import os, hashlib, json, shutil, time
root = os.path.expanduser(os.environ["ROOT"])
archive = os.path.expanduser(os.environ["ARCHIVE_ROOT"])
dry = int(os.environ.get("DRY_RUN","0"))
file_map = {}
for dirpath, dirs, files in os.walk(root):
    if dirpath.startswith(archive): continue
    for fn in files:
        fp = os.path.join(dirpath, fn)
        try:
            if not os.path.isfile(fp) or os.path.islink(fp): continue
            h = hashlib.sha256()
            with open(fp,"rb") as fh:
                for chunk in iter(lambda: fh.read(8192), b""): h.update(chunk)
            file_map.setdefault(h.hexdigest(), []).append(fp)
        except: continue
moved = []
for digest, paths in file_map.items():
    if len(paths)<2: continue
    paths_sorted = sorted(paths, key=lambda p: os.path.getmtime(p), reverse=True)
    keep, dupes = paths_sorted[0], paths_sorted[1:]
    for d in dupes:
        rel = os.path.relpath(d, root)
        target_dir = os.path.join(archive,"dedup","sha256",os.path.dirname(rel))
        os.makedirs(target_dir, exist_ok=True)
        target = os.path.join(target_dir, os.path.basename(d))
        if dry: moved.append({"from": d,"to": target,"digest":digest,"action":"DRY-RUN"})
        else:
            try: shutil.move(d,target); moved.append({"from":d,"to":target,"digest":digest})
            except Exception as e: moved.append({"from":d,"error":str(e)})
with open(os.path.join(archive,"dedup_sha256.json"),"w") as fh: json.dump({"moved":moved,"timestamp":time.time()},fh,indent=2)
PY

# 6) Deduplicate by basename (priority)
_log "Deduplicating duplicate basenames..."
export KEEP_PRIORITY_JOINED="$(printf '%s\n' "${KEEP_PRIORITY[@]}")"
python3 - <<'PY'
import os, json, shutil, time
root = os.path.expanduser(os.environ["ROOT"])
archive = os.path.expanduser(os.environ["ARCHIVE_ROOT"])
priority = os.environ.get("KEEP_PRIORITY_JOINED","").splitlines()
dry = int(os.environ.get("DRY_RUN","0"))
name_map={}
for dirpath, dirs, files in os.walk(root):
    if dirpath.startswith(archive): continue
    for fn in files: name_map.setdefault(fn,[]).append(os.path.join(dirpath,fn))
moved=[]
for name, paths in name_map.items():
    if len(paths)<2: continue
    keeper=None
    for pref in priority:
        for p in paths:
            if pref in p.replace("\\\\","/"): keeper=p; break
        if keeper: break
    if not keeper: keeper = sorted(paths,key=lambda p: os.path.getmtime(p),reverse=True)[0]
    for p in paths:
        if p==keeper: continue
        rel=os.path.relpath(p,root)
        target_dir=os.path.join(archive,"dedup","by_name",os.path.dirname(rel))
        os.makedirs(target_dir,exist_ok=True)
        target=os.path.join(target_dir,os.path.basename(p))
        if dry: moved.append({"from":p,"to":target,"kept":keeper,"action":"DRY-RUN"})
        else:
            try: shutil.move(p,target); moved.append({"from":p,"to":target,"kept":keeper})
            except Exception as e: moved.append({"from":p,"error":str(e)})
with open(os.path.join(archive,"dedup_by_name.json"),"w") as fh: json.dump({"moved":moved,"timestamp":time.time()},fh,indent=2)
PY

# 7) Remove empty directories (except whitelist)
_log "Removing empty directories (whitelist preserved)"
while IFS= read -r -d '' dir; do
    [[ "$dir" == "$ROOT" || "$dir" == "$ARCHIVE_ROOT"* ]] && continue
    bn="$(basename "$dir")"
    skip=0
    for w in "${WHITELIST_DIRS[@]}"; do [[ "$bn" == "$w" ]] && skip=1 && break; done
    [[ $skip -eq 1 ]] && continue
    [ -z "$(ls -A "$dir" 2>/dev/null)" ] && { $DRY_RUN -eq 1 && _log "[DRY-RUN] rmdir $dir" || { rmdir "$dir"; _log "removed empty: $dir"; } }
done < <(find "$ROOT" -type d -depth -print0)

# 8) Normalize permissions
_log "Normalizing permissions"
[ $DRY_RUN -eq 1 ] && _log "[DRY-RUN] chmod dirs->755, files->644, add +x to shebang scripts" || {
    find "$ROOT" -type d -not -path "$ARCHIVE_ROOT/*" -exec chmod 755 {} \; 2>/dev/null || true
    find "$ROOT" -type f -not -path "$ARCHIVE_ROOT/*" -exec chmod 644 {} \; 2>/dev/null || true
    while IFS= read -r -d '' f; do head -n1 "$f" 2>/dev/null | grep -q '^#!' && chmod +x "$f"; done < <(find "$ROOT" -type f -not -path "$ARCHIVE_ROOT/*" -print0)
}

# 9) Generate manifest
_log "Generating manifest"
python3 - <<PY > "$MANIFEST"
import os, json, time
root = os.path.abspath(os.environ["ROOT"])
archive = os.path.abspath(os.environ["ARCHIVE_ROOT"])
report = {"root":root,"archive":archive,"timestamp":"$TS","dry_run":bool($DRY_RUN)}
sections={}
for key in ["moved_tmp","moved_reports","dedup/sha256","dedup/by_name","logs_rotated","empties"]:
    p=os.path.join(archive,key)
    items=[]
    if os.path.exists(p):
        for dirpath, dirs, files in os.walk(p):
            for f in files: items.append(os.path.relpath(os.path.join(dirpath,f),archive))
    sections[key]={"count":len(items),"examples":items[:50]}
for fn in ["dedup_sha256.json","dedup_by_name.json"]:
    p=os.path.join(archive,fn)
    if os.path.exists(p):
        try:
            with open(p,"r") as fh: data=json.load(fh)
            sections[fn]={"present":True,"entries":len(data.get("moved",[]))}
        except: sections[fn]={"present":True}
report["sections"]=sections
report["note"]="Everything moved is stored in the archive folder. To restore, move files back from archive subfolders."
print(json.dumps(report,indent=2))
PY

_log "Cleanup complete. Archive location: $ARCHIVE_ROOT"
_log "Manifest: $MANIFEST"
_log "Use --dry-run to simulate actions; without it changes are applied."

exit 0
