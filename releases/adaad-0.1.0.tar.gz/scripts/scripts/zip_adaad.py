import os
import time
import zipfile

# 1) Source: internal/local ADAAD folder
SOURCE_DIR = os.path.expanduser("~/ADAAD")

# 2) Destination: Android Downloads folder
DEST_DIR = "/storage/emulated/0/Download"  # or "/storage/emulated/0/Downloads" if that's your path

os.makedirs(DEST_DIR, exist_ok=True)

# 3) Name for the backup zip
timestamp = time.strftime("%Y%m%d_%H%M%S")
zip_name = f"ADAAD_backup_{timestamp}.zip"
DEST_ZIP = os.path.join(DEST_DIR, zip_name)

def make_zip(source_dir, dest_zip):
    source_dir = os.path.abspath(source_dir)
    dest_zip = os.path.abspath(dest_zip)

    with zipfile.ZipFile(dest_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            for fname in files:
                full_path = os.path.join(root, fname)
                rel_path = os.path.relpath(full_path, source_dir)
                zf.write(full_path, rel_path)

    print("Created ZIP:", dest_zip)

if __name__ == "__main__":
    if not os.path.isdir(SOURCE_DIR):
        raise SystemExit(f"Source folder does not exist: {SOURCE_DIR}")
    make_zip(SOURCE_DIR, DEST_ZIP)
