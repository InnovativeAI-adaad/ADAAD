def main():
    print("ADAAD: ready")
if __name__ == "__main__":
    main()
