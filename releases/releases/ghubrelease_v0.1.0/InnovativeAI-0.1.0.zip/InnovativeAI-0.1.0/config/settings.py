API_TITLE = "ADAAD-Free API"
API_VERSION = "0.1.0"
DEBUG = False

# Optional external backend for private ADAAD mode
ADAAD_BACKEND_URL = None

