# ~/ad/core/dna/lineage.py

"""
Governed lineage and DNA ledger for ADAAD.

Responsibilities:
- Track ancestry of every agent
- Log mutations, promotions, failures, repairs
- Store all records in world-local logs (P1.0 isolation)
- Provide deterministic, queryable ancestry trees
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone

from runtime.context import RuntimeContext
from common.pathing import Pathing


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    """
    Append an event as JSONL to the lineage ledger.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, default=str) + "\n")


class Lineage:
    """
    World-local DNA & ancestry ledger.

    All lineage data is stored at:
      ~/ad/worlds/<world_id>/logs/lineage.jsonl
    """

    def __init__(self, ctx: RuntimeContext, paths: Pathing):
        self.ctx = ctx
        self.paths = paths
        self.log_path = self.paths.logs() / "lineage.jsonl"

    # --------------------------------------------------------
    # Event recording API
    # --------------------------------------------------------

    def record(
        self,
        event_type: str,
        agent: str,
        parent: Optional[str] = None,
        meta: Optional[Dict[str, Any]] = None,
    ):
        """
        Generic lineage event writer.
        """
        rec = {
            "ts": _now(),
            "world_id": self.ctx.world_id,
            "event": event_type,
            "agent": agent,
        }
        if parent:
            rec["parent"] = parent
        if meta:
            rec["meta"] = meta

        _append_jsonl(self.log_path, rec)
        return rec

    # Convenience structured event wrappers

    def mutation(self, offspring: str, parent: str, attempt: int):
        """
        Record that `offspring` was generated from `parent`.
        """
        return self.record("mutation", offspring, parent, {"attempt": attempt})

    def quarantine(self, agent: str, reason: str):
        """
        Agent quarantined due to failure.
        """
        return self.record("quarantine", agent, None, {"reason": reason})

    def promote(self, agent: str, score: float):
        """
        Agent promoted for high fitness.
        """
        return self.record("promote", agent, None, {"fitness": score})

    def repair(self, agent: str):
        """
        Agent repaired from broken state.
        """
        return self.record("repair", agent)

    # --------------------------------------------------------
    # Query methods
    # --------------------------------------------------------

    def load_all(self) -> List[Dict[str, Any]]:
        """
        Return all lineage events in this world.
        """
        if not self.log_path.exists():
            return []
        return [
            json.loads(line)
            for line in self.log_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]

    def ancestry_of(self, agent: str) -> List[Dict[str, Any]]:
        """
        All lineage events related to a specific agent.
        """
        records = self.load_all()
        return [r for r in records if r.get("agent") == agent]

    def children_of(self, parent: str) -> List[str]:
        """
        Return list of offspring of a given parent.
        """
        records = self.load_all()
        kids = []
        for r in records:
            if r.get("event") == "mutation" and r.get("parent") == parent:
                kids.append(r.get("agent"))
        return kids

    def tree(self, root_agent: str) -> Dict[str, Any]:
        """
        Recursively reconstruct the mutation tree of an agent.
        """
        children = self.children_of(root_agent)
        return {
            "agent": root_agent,
            "children": [self.tree(c) for c in children],
        }
