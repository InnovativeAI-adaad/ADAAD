# ~/ad/core/seed.py

from __future__ import annotations

from pathlib import Path
from typing import Dict, Any, List

from runtime.context import RuntimeContext
from common.pathing import PathFactory


class Seeder:
    """
    Seed manager for ADAAD worlds.

    Responsibilities:
    - Ensure each world has an initial live population.
    - Copy seed agents from the global seeds directory:
        ADAAD_ROOT/agents/seeds/*.py
    - Never write outside the governed world paths.
    """

    def __init__(self, ctx: RuntimeContext, paths: PathFactory, seed_dir: Path | None = None):
        self.ctx = ctx
        self.paths = paths

        # Default global seed directory: <ADAAD_ROOT>/agents/seeds
        if seed_dir is None:
            root = self.paths.adaad_root  # set in PathFactory.__init__
            seed_dir = root / "agents" / "seeds"

        self.seed_dir = seed_dir

    def ensure_seed_population(self, min_agents: int = 1) -> Dict[str, Any]:
        """
        Ensure the world has at least `min_agents` live agents.

        Returns a small status dict, e.g.:
        - {"ok": True, "action": "noop", "reason": "population_already_sufficient", "existing": 3}
        - {"ok": True, "action": "seeded", "copied": [...], "world_id": "..."}
        - {"ok": False, "action": "failed", "error": "...", "seed_dir": "..."}
        """
        live_dir = self.paths.agents_live()
        live_dir.mkdir(parents=True, exist_ok=True)

        existing = [p for p in live_dir.iterdir() if p.is_file() and p.suffix == ".py"]
        if len(existing) >= min_agents:
            return {
                "ok": True,
                "action": "noop",
                "reason": "population_already_sufficient",
                "existing": len(existing),
            }

        # No sufficient population → seed from global seeds
        if not self.seed_dir.exists():
            return {
                "ok": False,
                "action": "failed",
                "error": "no_global_seeds_found",
                "seed_dir": str(self.seed_dir),
            }

        seeds = [p for p in self.seed_dir.iterdir() if p.is_file() and p.suffix == ".py"]
        if not seeds:
            return {
                "ok": False,
                "action": "failed",
                "error": "no_seed_files_in_dir",
                "seed_dir": str(self.seed_dir),
            }

        copied: List[str] = []
        for seed in seeds:
            dest = live_dir / seed.name
            if not dest.exists():
                # simple text copy; world isolation is enforced by agents_live()
                dest.write_text(seed.read_text(encoding="utf-8"), encoding="utf-8")
                copied.append(str(dest))

        return {
            "ok": True,
            "action": "seeded" if copied else "noop",
            "copied": copied,
            "world_id": self.ctx.world_id,
        }
