# ~/ad/core/sandbox.py

"""
Governed execution sandbox for ADAAD.

This sandbox:
- Executes an agent's file safely
- Enforces world-level path isolation (P1.0)
- Uses subprocess to contain CPU, memory, and file access
- Captures stdout, stderr, exit code, runtime
- Provides a consistent, governed interface for BEAST, Dream Mode, and Cryovant

Note:
We DO NOT trust Python exec() inside the main process.
We always isolate in a subprocess.
"""

from __future__ import annotations

import subprocess
import time
import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Optional

from runtime.context import RuntimeContext
from common.pathing import Pathing


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Sandbox:
    """
    Subprocess-based execution cell.
    """

    def __init__(self, ctx: RuntimeContext, paths: Pathing):
        self.ctx = ctx
        self.paths = paths
        self.log_file = self.paths.logs() / "sandbox.jsonl"

    # --------------------------------------------------------
    # Logging helper
    # --------------------------------------------------------

    def _log(self, obj: Dict[str, Any]):
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        with self.log_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, default=str) + "\n")

    # --------------------------------------------------------
    # Execution
    # --------------------------------------------------------

    def run(self, agent_path: Path, timeout: int = 5) -> Dict[str, Any]:
        """
        Execute an agent file in a subprocess with strong boundaries.

        Returns:
            {
              "ts": "...",
              "agent": "...",
              "exit_code": int,
              "stdout": "...",
              "stderr": "...",
              "timed_out": bool,
              "runtime": float
            }
        """

        result = {
            "ts": _now(),
            "agent": str(agent_path),
            "timeout": timeout,
            "world_id": self.ctx.world_id,
        }

        # Ensure path is inside world (P1.0 guard)
        try:
            agent_path = self.paths.guard(agent_path)
        except Exception as e:
            result["error"] = f"path_escape:{e}"
            self._log(result)
            return result

        start = time.time()

        try:
            proc = subprocess.Popen(
                ["python3", str(agent_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(agent_path.parent),
            )

            try:
                out, err = proc.communicate(timeout=timeout)
                result["exit_code"] = proc.returncode
                result["stdout"] = out.decode("utf-8", errors="ignore")
                result["stderr"] = err.decode("utf-8", errors="ignore")
                result["timed_out"] = False

            except subprocess.TimeoutExpired:
                proc.kill()
                result["exit_code"] = -1
                result["stdout"] = ""
                result["stderr"] = "TIMEOUT"
                result["timed_out"] = True

        except Exception as e:
            result["exit_code"] = -2
            result["stdout"] = ""
            result["stderr"] = str(e)
            result["timed_out"] = False

        end = time.time()
        result["runtime"] = round(end - start, 4)

        self._log(result)
        return result
