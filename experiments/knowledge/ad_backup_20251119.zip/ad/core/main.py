# ~/ad/core/main.py

"""
ADAAD vNext — Governed BEAST Orchestrator

This orchestrator:
- Creates a RuntimeContext bound to a specific world
- Uses Factory to construct MutationEngine, Evaluator, Lineage
- Runs a simple BEAST-style cycle:
    1) mutate existing agents in this world
    2) score population
    3) record promotions in lineage
- All logs & artifacts are world-local (P1.0 isolation)
"""

from __future__ import annotations

import os
import time
import argparse
import json
import shutil
from pathlib import Path
from typing import Dict, Any, List

from runtime.context import RuntimeContext
from runtime.factory import Factory
from core.seed import Seeder
from core.dream_mode import DreamMode

def _root_from_env() -> Path:
    """
    Determine ADAAD root from env or fallback to ./ad.
    """
    env = os.environ.get("ADAAD_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    # default: assume we're running from project root ~/ad
    return Path(__file__).resolve().parents[1]

def _find_latest_world(root: Path) -> str | None:
    """
    Find the most recently modified world directory under root/worlds.
    Returns the world_id (directory name) or None if no worlds exist.
    """
    worlds_root = root / "worlds"
    if not worlds_root.exists():
        return None

    candidates = [
        d for d in worlds_root.iterdir()
        if d.is_dir()
    ]
    if not candidates:
        return None

    latest = max(candidates, key=lambda d: d.stat().st_mtime)
    return latest.name

def _build_factory(world_id: str | None, dry_run: bool, profile: str) -> Factory:
    root = _root_from_env()
    worlds_root = root / "worlds"

    if world_id and world_id != "default":
        # reuse an existing world id (no automatic folder wipe)
        ctx = RuntimeContext(world_id=world_id, dry_run=dry_run, mutation_profile=profile)
        # ensure world directory exists
        (worlds_root / world_id).mkdir(parents=True, exist_ok=True)
    elif world_id == "default":
        ctx = RuntimeContext.default()
    else:
        # create a brand-new world with generated id
        ctx = RuntimeContext.new(world_root=worlds_root, dry_run=dry_run, profile=profile)

    return Factory(ctx, root)

def _world_status(factory: Factory) -> Dict[str, Any]:
    """
    Summarise the current world:
      - live agent count
      - verified agent count
      - last fitness scores (if any)
    """
    ctx = factory.ctx
    paths = factory.paths

    live_dir = paths.agents_live()
    verified_dir = paths.agents_verified()
    logs_dir = paths.logs()

    live_files = [p for p in live_dir.glob("*.py")] if live_dir.exists() else []
    verified_files = [p for p in verified_dir.glob("*.py")] if verified_dir.exists() else []

    scoring_log = logs_dir / "scoring.jsonl"
    last_scores: List[Dict[str, Any]] = []

    if scoring_log.exists():
        try:
            with scoring_log.open("r", encoding="utf-8") as f:
                # keep only the last ~20 lines to avoid huge memory
                lines = f.readlines()[-20:]
            for ln in lines:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    obj = json.loads(ln)
                    last_scores.append(obj)
                except json.JSONDecodeError:
                    continue
        except OSError:
            pass

    # compute best fitness if present
    best_fitness = None
    best_agent = None
    for s in last_scores:
        if not isinstance(s, dict):
            continue
        if s.get("status") != "ok":
            continue
        fit = float(s.get("fitness", 0.0))
        if best_fitness is None or fit > best_fitness:
            best_fitness = fit
            best_agent = s.get("agent")

    return {
        "world_id": ctx.world_id,
        "live_count": len(live_files),
        "verified_count": len(verified_files),
        "logs_dir": str(logs_dir),
        "best_fitness": best_fitness,
        "best_agent": best_agent,
    }

def _cycle(factory: Factory, mutation_limit: int = 5, max_live: int | None = None) -> Dict[str, Any]:
    """
    One governed BEAST 2.0 cycle:
      - seed population if empty
      - mutate population
      - score population
      - promote strong agents to verified pool
      - cull weakest agents if population exceeds cap
    """
    if max_live is None:
        # reasonable default: allow 2× mutation_limit live agents
        max_live = max(5, mutation_limit * 2)

    ctx = factory.ctx
    paths = factory.paths
    mutation_engine = factory.mutation_engine()
    scorer = factory.scorer()
    dna = factory.dna()
    cry = factory.cryovant()
    seeder = Seeder(ctx, paths)

    # make sure population dir exists
    pop_dir = paths.agents_live()
    pop_dir.mkdir(parents=True, exist_ok=True)

    # 0) Seed if needed
    seed_info = seeder.ensure_seed_population(min_agents=1)

    # 1) Mutate population
    mutation_results: List[Dict[str, Any]] = mutation_engine.mutate_population(limit=mutation_limit)

    # 1b) Cryovant proofs for successful mutations
    for m in mutation_results:
        if not isinstance(m, dict):
            continue
        if m.get("status") != "ok":
            continue
        offspring = m.get("offspring")
        parent = m.get("source")
        attempt = m.get("attempt")
        if offspring and parent:
            cry.proof_mutation(offspring, parent, attempt)

    # 2) Score population (up to max_live agents)
    score_results = scorer.score_population(limit=max_live)
    scored = score_results.get("results", []) if isinstance(score_results, dict) else []

    # 3) Promotions — high fitness agents get promoted + copied to verified pool
    threshold = 0.69
    promotions: List[Dict[str, Any]] = []

    verified_dir = paths.agents_verified()
    verified_dir.mkdir(parents=True, exist_ok=True)

    fitness_map: Dict[Path, float] = {}

    for r in scored:
        if not isinstance(r, dict):
            continue
        if r.get("status") != "ok":
            continue

        agent = r.get("agent")
        if not agent:
            continue

        fitness = float(r.get("fitness", 0.0))
        agent_path = Path(agent)
        fitness_map[agent_path] = fitness

        if fitness >= threshold:
            dna.promote(agent, fitness)
            cry.proof_promotion(agent, fitness)
            promotions.append({"agent": agent, "fitness": fitness})

            # copy champion to verified pool
            if agent_path.exists():
                dst = verified_dir / agent_path.name
                shutil.copy2(agent_path, dst)

    # 4) Culling — keep population size under max_live by removing weakest agents
    live_files = [p for p in pop_dir.iterdir() if p.is_file() and p.suffix == ".py"]
    culled: List[str] = []

    if len(live_files) > max_live:
        # default fitness 0.0 for any unscored file
        def score_for(p: Path) -> float:
            return fitness_map.get(p, 0.0)

        # sort ascending: weakest first
        live_files_sorted = sorted(live_files, key=score_for)
        to_remove = live_files_sorted[: len(live_files) - max_live]

        for p in to_remove:
            dna.quarantine(str(p), reason="beast_cull_low_fitness")
            try:
                p.unlink()
            except FileNotFoundError:
                pass
            culled.append(str(p))

    return {
        "world_id": ctx.world_id,
        "seed": seed_info,
        "mutations": mutation_results,
        "scores": scored,
        "promotions": promotions,
        "culled": culled,
    }

def _find_latest_world(root: Path) -> str | None:
    """
    Find the most recently modified world directory under root/worlds.
    Returns the world_id (directory name) or None if no worlds exist.
    """
    worlds_root = root / "worlds"
    if not worlds_root.exists():
        return None

    candidates = [d for d in worlds_root.iterdir() if d.is_dir()]
    if not candidates:
        return None

    latest = max(candidates, key=lambda d: d.stat().st_mtime)
    return latest.name


def main():
    parser = argparse.ArgumentParser(description="ADAAD Governed BEAST Orchestrator")
    parser.add_argument("--world", type=str, default=None, help="World id to use (or create new if omitted)")
    parser.add_argument("--profile", type=str, default="default", help="Mutation profile name")
    parser.add_argument("--dry-run", action="store_true", help="Enable dry-run simulation mode")
    parser.add_argument("--once", action="store_true", help="Run a single cycle and exit")
    parser.add_argument("--interval", type=int, default=10, help="Seconds between cycles in loop mode")
    parser.add_argument("--limit", type=int, default=5, help="Max agents to mutate/score per cycle")
    parser.add_argument("--dream", action="store_true", help="Run Dream Mode instead of BEAST")
    parser.add_argument("--status", action="store_true", help="Show world status and exit")
    args = parser.parse_args()

    root = _root_from_env()



    # If we're in Dream Mode with no world specified, reuse latest world if possible
    if args.dream and args.world is None:
        latest = _find_latest_world(root)
        if latest is not None:
            print(f"[ADAAD] Dream Mode: auto-selecting latest world {latest}")
            args.world = latest
    # If we're in BEAST mode (not dream) with no world specified,
    # also reuse the latest world if one exists. If none exists, _build_factory
    # will create a fresh world.
    if not args.dream and args.world is None:
        latest = _find_latest_world(root)
        if latest is not None:
            print(f"[ADAAD] BEAST: auto-selecting latest world {latest}")
            args.world = latest
    factory = _build_factory(world_id=args.world,
                             dry_run=args.dry_run,
                             profile=args.profile)
    ctx = factory.ctx

    print(f"[ADAAD] Governed orchestrator starting")
    print(f"  root    = {root}")
    print(f"  world   = {ctx.world_id}")
    print(f"  dry_run = {ctx.dry_run}")
    print(f"  profile = {ctx.mutation_profile}")
# Status-only mode
    if args.status:
        status = _world_status(factory)
        print("[ADAAD] world status:")
        for k, v in status.items():
            print(f"  {k:14} = {v}")
        return
    # ---------------- Dream Mode branch ----------------
    if args.dream:
        from core.dream_mode import DreamMode

        dream_engine = DreamMode(
            ctx,
            factory.paths,
            factory.mutation_engine(),
            factory.scorer(),
            factory.sandbox(),
        )

        pop = factory.paths.agents_live()
        agents = [p for p in pop.iterdir() if p.is_file() and p.suffix == ".py"]

        if not agents:
            print("[ADAAD] Dream Mode: no agents to simulate.")
            return

        result = dream_engine.dream_on(agents, attempts=args.limit)
        print("[ADAAD] Dream Mode result:", result)
        return

    # ---------------- Single BEAST cycle ----------------
    if args.once:
        result = _cycle(factory, mutation_limit=args.limit)
        print("[ADAAD] cycle result:", result)
        return

    # ---------------- Loop mode (BEAST) ----------------
    try:
        while True:
            result = _cycle(factory, mutation_limit=args.limit)
            print(
                f"[ADAAD] cycle world={result['world_id']} "
                f"mutations={len(result['mutations'])} "
                f"promotions={len(result['promotions'])}"
            )
            time.sleep(max(1, args.interval))
    except KeyboardInterrupt:
        print("\n[ADAAD] orchestrator shutdown requested")


if __name__ == "__main__":
    main()
