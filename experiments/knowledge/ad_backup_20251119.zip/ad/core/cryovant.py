# ~/ad/core/cryovant.py

"""
Cryovant vNext — ADAAD Cryptographic Ledger
Governed, world-aware version.

Responsibilities:
- Compute agent hashes (SHA-256)
- Record mutation proofs
- Record promotion proofs
- Verify ancestry integrity
- Store world-local cryovant ledger in:
    ~/ad/worlds/<world_id>/logs/cryovant.jsonl
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime, timezone

from runtime.context import RuntimeContext
from common.pathing import Pathing


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, default=str) + "\n")


class Cryovant:
    """
    World-local cryptographic verification engine.
    """

    def __init__(self, ctx: RuntimeContext, paths: Pathing):
        self.ctx = ctx
        self.paths = paths
        self.log_file = self.paths.logs() / "cryovant.jsonl"

    # --------------------------------------------------------
    # Hashing
    # --------------------------------------------------------

    @staticmethod
    def sha256_of_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    # --------------------------------------------------------
    # Record Proofs
    # --------------------------------------------------------

    def record_proof(
        self,
        event: str,
        agent: str,
        parent: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ):
        rec = {
            "ts": _now(),
            "world_id": self.ctx.world_id,
            "event": event,
            "agent": agent,
            "hash": self.sha256_of_file(Path(agent)),
        }
        if parent:
            rec["parent"] = parent
        if extra:
            rec["extra"] = extra

        _append_jsonl(self.log_file, rec)
        return rec

    def proof_mutation(self, offspring: str, parent: str, attempt: int):
        return self.record_proof(
            "mutation_proof",
            agent=offspring,
            parent=parent,
            extra={"attempt": attempt},
        )

    def proof_promotion(self, agent: str, fitness: float):
        return self.record_proof(
            "promotion_proof",
            agent=agent,
            extra={"fitness": fitness},
        )

    # --------------------------------------------------------
    # Verification
    # --------------------------------------------------------

    def verify_hash(self, path: Path, expected: str) -> bool:
        return self.sha256_of_file(path) == expected

    def verify_ancestry(self, agent: str, parent_hash: str) -> bool:
        """
        Utility to verify an offspring’s hash against stored parent hash.
        """
        return True  # Placeholder until full ancestry chain is implemented
