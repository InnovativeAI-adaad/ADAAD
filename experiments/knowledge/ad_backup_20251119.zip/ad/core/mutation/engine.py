# ~/ad/core/mutation/engine.py

from __future__ import annotations

import json
import random
import uuid
import ast
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, List

from runtime.context import RuntimeContext
from common.pathing import PathFactory


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, default=str) + "\n")


class MutationEngine:
    """
    World-governed mutation engine.

    Responsibilities:
    - Operate only inside the current world's live agents directory.
    - Produce syntactically valid offspring.
    - Log all mutation attempts to mutations.jsonl.

    This version keeps the mutation operator intentionally simple:
    - Copy the parent source
    - Append a harmless mutation marker comment
    - Give the file a new `_m1_<suffix>.py` name
    """

    def __init__(self, ctx: RuntimeContext, paths: PathFactory):
        self.ctx = ctx
        self.paths = paths
        self.log_file = self.paths.logs() / "mutations.jsonl"

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def mutate_population(self, limit: int = 5) -> List[Dict[str, Any]]:
        """
        Pick up to `limit` parents from the world's live population and
        generate one offspring per parent.

        Returns: list of event dicts, e.g.
        {
          "ts": "...",
          "world_id": "...",
          "source": "...",
          "status": "ok",
          "attempt": 1,
          "offspring": "..."
        }
        """
        live_dir = self.paths.agents_live()
        if not live_dir.exists():
            return []

        parents = [p for p in live_dir.iterdir() if p.is_file() and p.suffix == ".py"]
        if not parents:
            return []

        # Most recently modified first for a little bias toward "fresh" code
        parents.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        parents = parents[:limit]

        results: List[Dict[str, Any]] = []
        for parent in parents:
            results.append(self._mutate_one(parent))

        return results

    # ---------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------

    def _mutate_one(self, parent: Path) -> Dict[str, Any]:
        event: Dict[str, Any] = {
            "ts": _now(),
            "world_id": self.ctx.world_id,
            "source": str(parent),
            "status": "start",
            "attempt": 1,
        }

        try:
            if not parent.exists():
                event["status"] = "error"
                event["error"] = "missing_parent"
                _append_jsonl(self.log_file, event)
                return event

            source = parent.read_text(encoding="utf-8")
            mutated = self._simple_mutation(source)

            # Validate syntax so we don't poison the pool
            self._validate_python(mutated)

            suffix = f"{random.randint(1000, 9999)}"
            child_name = f"{parent.stem}_m1_{suffix}{parent.suffix}"
            child = parent.with_name(child_name)

            child.write_text(mutated, encoding="utf-8")

            event["status"] = "ok"
            event["offspring"] = str(child)

            _append_jsonl(self.log_file, event)
            return event

        except Exception as exc:
            event["status"] = "error"
            event["error"] = str(exc)
            _append_jsonl(self.log_file, event)
            return event

    def _simple_mutation(self, source: str) -> str:
        """
        Minimal, safe mutation:
        - Keep the original code
        - Append a harmless comment with a unique marker

        This guarantees syntactically valid Python while still
        changing the file structure enough for scoring + Cryovant.
        """
        marker = uuid.uuid4().hex[:8]
        return source + f"\n\n# adaad_mutation_marker {marker}\n"

    def _validate_python(self, source: str) -> None:
        """
        Ensure the mutated source can be parsed by Python.
        Raises SyntaxError if invalid.
        """
        ast.parse(source)
