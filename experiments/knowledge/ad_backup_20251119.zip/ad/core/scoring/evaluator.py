# ~/ad/core/scoring/evaluator.py

"""
Governed scoring engine for ADAAD.
Provides deterministic, world-local fitness evaluations.

This module:
- Loads an agent file
- Evaluates STRUCTURE (syntax, shape, key functions)
- Optionally evaluates BEHAVIOR on simple test cases
- Assigns a reproducible fitness value
- Logs scoring events inside the world’s logs directory
"""

from __future__ import annotations

import json
import traceback
import runpy
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, Tuple

from runtime.context import RuntimeContext
from common.pathing import PathFactory  # type: ignore[import]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, default=str) + "\n")


class Evaluator:
    """
    World-governed fitness evaluator.

    Fitness is a blend of:
    - STRUCTURAL SCORE  (static code shape & features)
    - BEHAVIOR SCORE    (optional task performance via run())

    Behavior score is world-local:
    - looks for a JSON test file in paths.data() / "task_tests.json"
    - if missing, behavior_score = 0.0 (no task defined)
    """

    def __init__(self, ctx: RuntimeContext, paths: PathFactory):
        self.ctx = ctx
        self.paths = paths
        self.log_file = self.paths.logs() / "scoring.jsonl"

    # --------------------------------------------------------
    # Public API
    # --------------------------------------------------------

    def score_file(self, agent_path: Path) -> Dict[str, Any]:
        event: Dict[str, Any] = {
            "ts": _now(),
            "world_id": self.ctx.world_id,
            "agent": str(agent_path),
            "status": "start",
        }

        try:
            if not agent_path.exists():
                event["status"] = "error"
                event["error"] = "missing_agent"
                _append_jsonl(self.log_file, event)
                return event

            text = agent_path.read_text(encoding="utf-8")
            lines = text.splitlines()

            # ---------- STRUCTURAL COMPONENT ----------
            struct_score = self._structural_score(text, lines)

            # ---------- BEHAVIORAL COMPONENT ----------
            behavior_score, cases_total, cases_passed = self._behavior_score(agent_path)

            # Blend scores: structural (60%), behavior (40%)
            raw_score = (0.6 * struct_score) + (0.4 * behavior_score)
            fitness = max(0.0, min(1.0, round(raw_score, 4)))

            event.update(
                {
                    "status": "ok",
                    "fitness": fitness,
                    "struct_score": round(struct_score, 4),
                    "behavior_score": round(behavior_score, 4),
                    "cases_total": cases_total,
                    "cases_passed": cases_passed,
                }
            )

            _append_jsonl(self.log_file, event)
            return event

        except Exception as e:
            event["status"] = "error"
            event["error"] = str(e)
            event["trace"] = traceback.format_exc()
            _append_jsonl(self.log_file, event)
            return event

    def score_population(self, limit: int = 10) -> Dict[str, Any]:
        pop = self.paths.agents_live()

        if not pop.exists():
            return {"ok": False, "error": "population_missing"}

        files = [p for p in pop.iterdir() if p.is_file() and p.suffix == ".py"]
        files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        files = files[:limit]

        out = []
        for f in files:
            out.append(self.score_file(f))

        return {"ok": True, "results": out}

    # --------------------------------------------------------
    # Structural scoring
    # --------------------------------------------------------

    def _structural_score(self, text: str, lines: List[str]) -> float:
        """
        Very cheap, deterministic heuristic based only on the source text.
        """

        score = 0.0

        # (1) Reward presence of key behaviors
        if "def run" in text:
            score += 0.35
        if "def info" in text:
            score += 0.20
        if "def mutate" in text:
            score += 0.20

        # (2) Structural complexity penalty
        non_empty = [ln for ln in lines if ln.strip()]
        n = len(non_empty)
        complexity_penalty = min(0.25, n * 0.0005)
        score += (0.25 - complexity_penalty)

        # (3) Deterministic "entropy noise"
        stable_hash = (len(text) * 17 + sum(ord(c) for c in text[:200])) % 1000
        score += (stable_hash / 10000)

        # Clamp [0,1]
        return max(0.0, min(1.0, score))

    # --------------------------------------------------------
    # Behavioral scoring
    # --------------------------------------------------------

    def _load_test_cases(self) -> Tuple[List[Dict[str, Any]], str]:
        """
        Load behavior test cases from the world-local data directory.

        Expected file:
          paths.data() / "task_tests.json"

        Format:
        {
          "task": "reverse-string-v1",
          "cases": [
            {"input": "hello", "expected": "olleh"},
            {"input": "AdaAD", "expected": "DAadA"}
          ]
        }

        If file is missing or invalid, returns ([], "reason").
        """
        data_dir = self.paths.data()
        test_file = data_dir / "task_tests.json"

        if not test_file.exists():
            return [], "no_task_file"

        try:
            raw = json.loads(test_file.read_text(encoding="utf-8"))
        except Exception:
            return [], "task_file_invalid_json"

        if isinstance(raw, dict) and "cases" in raw and isinstance(raw["cases"], list):
            return raw["cases"], str(raw.get("task", "unnamed_task"))

        if isinstance(raw, list):
            return raw, "unnamed_list_task"

        return [], "task_file_bad_schema"

    def _behavior_score(self, agent_path: Path) -> Tuple[float, int, int]:
        """
        Execute agent.run(input) against simple test cases.

        - If no test file exists: returns (0.0, 0, 0)
        - If agent has no 'run' callable: returns (0.0, N, 0)
        - Exceptions in run() are counted as failures.
        """

        cases, _task_name = self._load_test_cases()
        if not cases:
            return 0.0, 0, 0

        # Load the agent module in an isolated namespace
        try:
            globals_dict = runpy.run_path(str(agent_path), run_name="__agent__")
        except Exception:
            # completely broken module → no behavior score
            return 0.0, len(cases), 0

        run_fn = globals_dict.get("run")
        if not callable(run_fn):
            return 0.0, len(cases), 0

        passed = 0
        total = 0

        for case in cases:
            if not isinstance(case, dict):
                continue
            inp = case.get("input")
            exp = case.get("expected")

            # Only handle simple string IO for now
            if not isinstance(inp, str) or not isinstance(exp, str):
                continue

            total += 1
            try:
                out = run_fn(inp)
            except Exception:
                continue

            if isinstance(out, str) and out == exp:
                passed += 1

        if total == 0:
            return 0.0, 0, 0

        # behavior score = fraction of passed cases
        return passed / total, total, passed
