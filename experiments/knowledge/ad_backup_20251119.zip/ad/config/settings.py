#!/usr/bin/env python3
"""
General settings.
"""
