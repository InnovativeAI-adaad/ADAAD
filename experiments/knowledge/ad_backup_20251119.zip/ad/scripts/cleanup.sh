#!/usr/bin/env python3
"""
Cleanup script.
"""
