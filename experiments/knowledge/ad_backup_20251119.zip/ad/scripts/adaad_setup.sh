#!/data/data/com.termux/files/usr/bin/bash
# Ultra-minimal ADAAD Project Setup Script
# Creates ~/ad/ and unpacks all scaffolding directly into it.

set -e

# New base directory (your requirement)
PROJECT_ROOT="$HOME/ad"

echo ">> Initializing ADAAD structure in: $PROJECT_ROOT"
mkdir -p "$PROJECT_ROOT"

# --- directory layout ---
DIRS=(
  agents tools workflows api auth cognition/memory config/environments
  data/state data/knowledge_bases deployment/docker deployment/kubernetes
  deployment/terraform docs evaluation execution logs models/prompts/system_prompts
  models/prompts/task_prompts providers scripts tests/api tests/cognition tests/execution
  tests/agents tests/utils tests/fixtures tests/integration tests/unit tests/e2e
  utils/retry utils/validation utils/serialization utils/formatters
)

for d in "${DIRS[@]}"; do
  mkdir -p "$PROJECT_ROOT/$d"
done

# -- helper: create placeholder file ---
create_placeholder() {
  local path="$1"
  local desc="$2"
  if [ ! -f "$path" ]; then
    echo "#!/usr/bin/env python3" > "$path"
    echo "\"\"\"" >> "$path"
    echo "$desc" >> "$path"
    echo "\"\"\"" >> "$path"
    chmod +x "$path"
    echo "created $path"
  else
    echo "exists   $path"
  fi
}

# --- agents ---
create_placeholder "$PROJECT_ROOT/agents/base_agent.py" "Base class for agents."
create_placeholder "$PROJECT_ROOT/agents/autonomous_agent.py" "Autonomous agent logic."
create_placeholder "$PROJECT_ROOT/agents/planner_agent.py" "Task planning agent."
create_placeholder "$PROJECT_ROOT/agents/agent_interface.py" "Interface for agent operations."
create_placeholder "$PROJECT_ROOT/agents/team_orchestrator.py" "Team orchestration core."
create_placeholder "$PROJECT_ROOT/agents/step_handler.py" "Step execution handler."
create_placeholder "$PROJECT_ROOT/agents/task_manager.py" "Task lifecycle manager."

# tools
create_placeholder "$PROJECT_ROOT/agents/tools/calculator.py" "Calculator tool."
create_placeholder "$PROJECT_ROOT/agents/tools/file_manager.py" "File management tool."
create_placeholder "$PROJECT_ROOT/agents/tools/search_tool.py" "Search abstraction."
create_placeholder "$PROJECT_ROOT/agents/tools/tool_registry.py" "Tool registry."

# workflows
create_placeholder "$PROJECT_ROOT/agents/workflows/code_review_chain.py" "Workflow: code review."
create_placeholder "$PROJECT_ROOT/agents/workflows/research_chain.py" "Workflow: research."
create_placeholder "$PROJECT_ROOT/agents/workflows/workflow_executor.py" "Workflow execution."
create_placeholder "$PROJECT_ROOT/agents/workflows/multi_agent_workflow.yaml" "YAML workflow definitions."

# api
create_placeholder "$PROJECT_ROOT/api/main.py" "FastAPI entry point."
create_placeholder "$PROJECT_ROOT/api/agent_routes.py" "Agent API endpoints."
create_placeholder "$PROJECT_ROOT/api/tool_routes.py" "Tool API endpoints."
create_placeholder "$PROJECT_ROOT/api/auth_routes.py" "Auth endpoints."
create_placeholder "$PROJECT_ROOT/api/websocket_server.py" "WebSocket event server."

# auth
create_placeholder "$PROJECT_ROOT/auth/access_control.py" "RBAC and permissions."
create_placeholder "$PROJECT_ROOT/auth/jwt.py" "JWT utilities."
create_placeholder "$PROJECT_ROOT/auth/user_manager.py" "User management."

# cognition
create_placeholder "$PROJECT_ROOT/cognition/cognitive_loop.py" "Core reasoning loop."
create_placeholder "$PROJECT_ROOT/cognition/decision_policy.py" "Decision policy."
create_placeholder "$PROJECT_ROOT/cognition/planner.py" "Planner engine."
create_placeholder "$PROJECT_ROOT/cognition/reasoner.py" "Reasoner module."
create_placeholder "$PROJECT_ROOT/cognition/state_interpreter.py" "State interpreter."
create_placeholder "$PROJECT_ROOT/cognition/memory/long_term_memory.py" "Long-term memory."
create_placeholder "$PROJECT_ROOT/cognition/memory/short_term_memory.py" "Short-term memory."
create_placeholder "$PROJECT_ROOT/cognition/memory/memory_manager.py" "Memory manager."

# config
create_placeholder "$PROJECT_ROOT/config/settings.py" "General settings."
create_placeholder "$PROJECT_ROOT/config/environments/dev.py" "Dev config."
create_placeholder "$PROJECT_ROOT/config/environments/prod.py" "Prod config."
create_placeholder "$PROJECT_ROOT/config/version.py" "Version file."

echo "# Example configuration file" > "$PROJECT_ROOT/config/.env.example"

# deployment docker/k8s/terraform
create_placeholder "$PROJECT_ROOT/deployment/docker/Dockerfile" "Docker build spec."
create_placeholder "$PROJECT_ROOT/deployment/docker/entrypoint.sh" "Docker entrypoint."
create_placeholder "$PROJECT_ROOT/deployment/kubernetes/deployment.yaml" "K8s Deployment."
create_placeholder "$PROJECT_ROOT/deployment/kubernetes/service.yaml" "K8s Service."
create_placeholder "$PROJECT_ROOT/deployment/kubernetes/ingress.yaml" "K8s Ingress."
create_placeholder "$PROJECT_ROOT/deployment/terraform/main.tf" "Terraform main config."
create_placeholder "$PROJECT_ROOT/deployment/terraform/variables.tf" "Terraform variables."
create_placeholder "$PROJECT_ROOT/deployment/terraform/outputs.tf" "Terraform outputs."

# docs
create_placeholder "$PROJECT_ROOT/docs/architecture.md" "System architecture docs."
create_placeholder "$PROJECT_ROOT/docs/api_reference.md" "API documentation."
create_placeholder "$PROJECT_ROOT/docs/usage.md" "Usage guide."

# evaluation
create_placeholder "$PROJECT_ROOT/evaluation/memory_eval.py" "Memory evaluation."
create_placeholder "$PROJECT_ROOT/evaluation/test_harness.py" "Test harness."
create_placeholder "$PROJECT_ROOT/evaluation/profiling_tools.py" "Profiling utilities."

# execution
create_placeholder "$PROJECT_ROOT/execution/action_resolver.py" "Action resolver."
create_placeholder "$PROJECT_ROOT/execution/controller.py" "Execution controller."
create_placeholder "$PROJECT_ROOT/execution/error_handler.py" "Error handler."
create_placeholder "$PROJECT_ROOT/execution/executor.py" "Executor."
create_placeholder "$PROJECT_ROOT/execution/job_scheduler.py" "Job scheduler."
create_placeholder "$PROJECT_ROOT/execution/background_worker.py" "Async background worker."

# logs
touch "$PROJECT_ROOT/logs/agent.log" "$PROJECT_ROOT/logs/api.log" "$PROJECT_ROOT/logs/auth.log" "$PROJECT_ROOT/logs/system.log"

# models
create_placeholder "$PROJECT_ROOT/models/cache.py" "Model cache."
create_placeholder "$PROJECT_ROOT/models/model_loader.py" "Model loader."
create_placeholder "$PROJECT_ROOT/models/embeddings.py" "Embedding utilities."
create_placeholder "$PROJECT_ROOT/models/llm_wrapper.py" "LLM wrapper."
create_placeholder "$PROJECT_ROOT/models/prompts/system_prompts/agent_roles.txt" "Agent role prompts."
create_placeholder "$PROJECT_ROOT/models/prompts/task_prompts/planning_prompts.txt" "Planning prompts."
create_placeholder "$PROJECT_ROOT/models/prompts/prompt_templates.yaml" "Prompt templates."

# providers
create_placeholder "$PROJECT_ROOT/providers/mcp_service_client.py" "MCP client."
create_placeholder "$PROJECT_ROOT/providers/external_service_a.py" "External service A."
create_placeholder "$PROJECT_ROOT/providers/external_service_b.py" "External service B."

# scripts
create_placeholder "$PROJECT_ROOT/scripts/cleanup.sh" "Cleanup script."
create_placeholder "$PROJECT_ROOT/scripts/deploy.sh" "Deploy script."
create_placeholder "$PROJECT_ROOT/scripts/run_local.sh" "Local runner."
create_placeholder "$PROJECT_ROOT/scripts/manage.py" "Management CLI."

# utils
create_placeholder "$PROJECT_ROOT/utils/exceptions.py" "Custom exceptions."
create_placeholder "$PROJECT_ROOT/utils/logger.py" "Logging config."
create_placeholder "$PROJECT_ROOT/utils/retry/decorators.py" "Retry decorators."
create_placeholder "$PROJECT_ROOT/utils/timers.py" "Timing utilities."
create_placeholder "$PROJECT_ROOT/utils/validation/schemas.py" "Validation schemas."
create_placeholder "$PROJECT_ROOT/utils/serialization/agent_serializer.py" "Agent serializer."
create_placeholder "$PROJECT_ROOT/utils/serialization/plan_serializer.py" "Plan serializer."
create_placeholder "$PROJECT_ROOT/utils/formatters/json_formatter.py" "JSON formatter."
create_placeholder "$PROJECT_ROOT/utils/formatters/yaml_formatter.py" "YAML formatter."
create_placeholder "$PROJECT_ROOT/utils/common_helpers.py" "Common helper functions."

# Markdown files
echo "# README" > "$PROJECT_ROOT/README.md"
echo "# CONTRIBUTING" > "$PROJECT_ROOT/CONTRIBUTING.md"

# Gitignore
cat > "$PROJECT_ROOT/.gitignore" <<EOF
__pycache__/
*.pyc
env/
.venv/
adaad_venv/
dist/
*.egg-info/
EOF

# --- self-unload ---
cp "$0" "$PROJECT_ROOT/scripts/adaad_setup.sh"

echo ">> ADAAD project initialized in ~/ad/"
echo ">> Setup script stored at ~/ad/scripts/adaad_setup.sh"