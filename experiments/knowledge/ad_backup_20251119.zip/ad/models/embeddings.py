#!/usr/bin/env python3
"""
Embedding utilities.
"""
