#!/usr/bin/env python3
"""
Agent API endpoints.
"""
