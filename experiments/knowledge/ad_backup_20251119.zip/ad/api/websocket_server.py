#!/usr/bin/env python3
"""
WebSocket event server.
"""
