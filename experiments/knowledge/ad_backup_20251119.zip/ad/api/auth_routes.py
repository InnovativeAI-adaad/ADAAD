#!/usr/bin/env python3
"""
Auth endpoints.
"""
