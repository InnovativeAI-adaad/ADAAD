#!/usr/bin/env python3
"""
FastAPI entry point.
"""
