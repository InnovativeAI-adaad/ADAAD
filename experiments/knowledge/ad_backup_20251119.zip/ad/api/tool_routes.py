#!/usr/bin/env python3
"""
Tool API endpoints.
"""
