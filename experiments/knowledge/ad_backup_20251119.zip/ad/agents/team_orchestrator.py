"""
TeamOrchestrator coordinates multiple agents working together towards a common
goal. It manages agent registration, dispatches goals or tasks to agents
according to configured workflows, and aggregates results. The orchestrator
allows for sequential or parallel execution strategies; this simple
implementation processes agents sequentially for clarity.
"""

from __future__ import annotations

from typing import List, Dict, Any, Iterable

from .base_agent import BaseAgent


class TeamOrchestrator:
    """Manage and coordinate a collection of agents."""

    def __init__(self) -> None:
        self._agents: List[BaseAgent] = []

    def register_agent(self, agent: BaseAgent) -> None:
        """Add an agent to the orchestrator."""
        self._agents.append(agent)

    def remove_agent(self, agent: BaseAgent) -> None:
        """Remove an agent from the orchestrator."""
        self._agents = [a for a in self._agents if a is not agent]

    def run(self, cycles: int = 1) -> List[Dict[str, Any]]:
        """Run all agents for a number of cycles.

        Returns a list of results from each agent's run method. Individual
        agents may return any type; the orchestrator collects these results
        into a list. Use this for simple sequential execution. For more
        complex workflows, override this method and implement parallelism or
        workflow logic.
        """
        results: List[Any] = []
        for agent in self._agents:
            result = agent.run(cycles)
            results.append(result)
        return results

    def __iter__(self) -> Iterable[BaseAgent]:  # pragma: no cover
        return iter(self._agents)