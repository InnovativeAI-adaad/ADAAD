#!/usr/bin/env python3
"""
Workflow execution.
"""
