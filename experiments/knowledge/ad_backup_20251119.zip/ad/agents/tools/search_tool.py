"""
SearchTool allows agents to perform web searches and retrieve summaries.

In offline environments or when internet access is disabled, the tool will
return an error. When network is available, it tries to use Python's
standard library `urllib` to fetch search results from DuckDuckGo's HTML
service and extract snippets. This is a lightweight alternative to heavy
search APIs.
"""

from __future__ import annotations

import urllib.parse
import urllib.request
from html.parser import HTMLParser
from typing import Any, Dict, List


class _DuckDuckGoParser(HTMLParser):
    """Simple HTML parser to extract snippets from DuckDuckGo search results."""

    def __init__(self) -> None:
        super().__init__()
        self.in_result = False
        self.snippets: List[str] = []

    def handle_starttag(self, tag: str, attrs: List[tuple]) -> None:
        if tag == "a":
            for name, value in attrs:
                if name == "class" and "result__a" in value:
                    self.in_result = True

    def handle_endtag(self, tag: str) -> None:
        if self.in_result and tag == "a":
            self.in_result = False

    def handle_data(self, data: str) -> None:
        if self.in_result:
            snippet = data.strip()
            if snippet:
                self.snippets.append(snippet)


class SearchTool:
    """Agent-callable search tool using DuckDuckGo's HTML interface."""

    def name(self) -> str:
        return "search"

    def description(self) -> str:
        return "Perform a web search and return summaries of results."

    def parameters(self) -> Dict[str, Any]:
        return {
            "query": {
                "type": "string",
                "description": "Search query string"
            },
            "max_results": {
                "type": "integer",
                "description": "Number of results to return",
                "default": 3
            }
        }

    def execute(self, query: str, max_results: int = 3) -> Dict[str, Any]:
        """Execute the search and return a list of result summaries."""
        try:
            url = "https://duckduckgo.com/html/?q=" + urllib.parse.quote(query)
            with urllib.request.urlopen(url, timeout=10) as response:
                html = response.read().decode("utf-8", errors="ignore")
            parser = _DuckDuckGoParser()
            parser.feed(html)
            snippets = parser.snippets[:max_results]
            return {"snippets": snippets}
        except Exception as exc:
            return {"error": str(exc), "hint": "Search may not be available offline."}