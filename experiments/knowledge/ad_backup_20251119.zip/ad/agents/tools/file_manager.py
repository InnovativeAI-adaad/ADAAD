"""
FileManager tool provides basic file system operations for agents.

Supported operations:
    - read: Read the contents of a file.
    - write: Write text to a file, overwriting or appending.
    - list: List files in a directory.
    - delete: Delete a file.

This tool restricts operations to the agent's working directory by default
and checks for path traversal to prevent security issues.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List


class FileManagerTool:
    """Agent-callable file management tool."""

    def __init__(self, root_dir: str | None = None) -> None:
        # Restrict file operations to this root directory
        self.root_dir = os.path.abspath(root_dir or os.getcwd())

    def name(self) -> str:
        return "file_manager"

    def description(self) -> str:
        return "Perform basic file system operations (read, write, list, delete)."

    def parameters(self) -> Dict[str, Any]:
        return {
            "operation": {
                "type": "string",
                "enum": ["read", "write", "list", "delete"],
                "description": "The file operation to perform."
            },
            "path": {
                "type": "string",
                "description": "Path of the file or directory relative to the root."
            },
            "content": {
                "type": "string",
                "description": "Content to write (for write operation)",
                "optional": True
            },
            "append": {
                "type": "boolean",
                "description": "Whether to append to the file (if write)",
                "optional": True
            }
        }

    def execute(self, operation: str, path: str, content: str = "", append: bool = False) -> Dict[str, Any]:
        """Execute a file operation and return its result."""
        full_path = os.path.abspath(os.path.join(self.root_dir, path))
        # Prevent path traversal outside the root directory
        if not full_path.startswith(self.root_dir):
            return {"error": "Access denied: path outside of root"}
        try:
            if operation == "read":
                with open(full_path, "r", encoding="utf-8") as f:
                    return {"content": f.read()}
            if operation == "write":
                mode = "a" if append else "w"
                with open(full_path, mode, encoding="utf-8") as f:
                    f.write(content)
                return {"success": True}
            if operation == "list":
                if not os.path.isdir(full_path):
                    return {"error": "Not a directory"}
                return {"files": os.listdir(full_path)}
            if operation == "delete":
                os.remove(full_path)
                return {"success": True}
            return {"error": f"Unknown operation: {operation}"}
        except FileNotFoundError:
            return {"error": "File or directory not found"}
        except PermissionError:
            return {"error": "Permission denied"}
        except Exception as exc:
            return {"error": str(exc)}