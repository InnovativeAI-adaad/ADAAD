"""
TaskManager provides a simple abstraction around a queue of tasks to be
consumed by agents. It supports adding tasks, retrieving the next task,
peeking at upcoming tasks, and determining whether the queue is empty.

This component can be used directly by agents or orchestrators to
coordinate work across multiple workers. For more complex scheduling or
prioritisation, consider extending this class or integrating with a
priority queue.
"""

from __future__ import annotations

from typing import List, Dict, Any, Optional


class TaskManager:
    """Manage a FIFO queue of tasks."""

    def __init__(self) -> None:
        self._tasks: List[Dict[str, Any]] = []

    def add_task(self, task: Dict[str, Any]) -> None:
        self._tasks.append(task)

    def next_task(self) -> Optional[Dict[str, Any]]:
        if not self._tasks:
            return None
        return self._tasks.pop(0)

    def peek(self) -> Optional[Dict[str, Any]]:
        return self._tasks[0] if self._tasks else None

    def is_empty(self) -> bool:
        return not self._tasks

    def __len__(self) -> int:
        return len(self._tasks)