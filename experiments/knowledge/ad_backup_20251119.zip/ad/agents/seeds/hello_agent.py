"""
HelloAgent — simple starter agent for ADAAD worlds.
"""

class Agent:
    def __init__(self, name: str = "HelloAgent"):
        self.name = name

    def run(self, task: str | None = None):
        return {
            "status": "ok",
            "agent": self.name,
            "task": task or "idle",
            "message": "Hello from a seeded agent."
        }

agent = Agent()

def run(text: str) -> str:
    """
    Simple behavioral task for BEAST.
    Reverse the input string.
    """
    return text[::-1]
