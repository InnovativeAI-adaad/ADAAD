#!/usr/bin/env python3
"""
Async background worker.
"""
