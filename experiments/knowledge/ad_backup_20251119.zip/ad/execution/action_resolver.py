#!/usr/bin/env python3
"""
Action resolver.
"""
