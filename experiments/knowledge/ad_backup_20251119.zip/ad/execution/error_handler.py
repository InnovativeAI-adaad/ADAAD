#!/usr/bin/env python3
"""
Error handler.
"""
