#!/usr/bin/env python3
"""
Plan serializer.
"""
