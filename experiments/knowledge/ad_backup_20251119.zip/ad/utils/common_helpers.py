"""
Common helper functions used throughout the ADAAD project.

These helpers avoid duplicating code across modules. Examples include
time formatting, safe data conversions, and simple list utilities.
"""

from __future__ import annotations

import datetime
from typing import Any, Iterable, List, TypeVar, Callable


def now_isoformat() -> str:
    """Return the current UTC time in ISO-8601 format."""
    return datetime.datetime.utcnow().isoformat() + "Z"


T = TypeVar("T")


def flatten(nested: Iterable[Iterable[T]]) -> List[T]:
    """Flatten a nested iterable into a single list."""
    return [item for sublist in nested for item in sublist]


def filter_none(values: Iterable[T]) -> List[T]:
    """Return a list with all None values removed."""
    return [v for v in values if v is not None]