#!/usr/bin/env python3
"""
Timing utilities.
"""
