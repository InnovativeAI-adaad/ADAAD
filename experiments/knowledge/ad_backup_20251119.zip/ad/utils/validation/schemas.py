#!/usr/bin/env python3
"""
Validation schemas.
"""
