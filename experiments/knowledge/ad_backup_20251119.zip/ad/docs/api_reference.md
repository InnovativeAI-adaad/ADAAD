#!/usr/bin/env python3
"""
API documentation.
"""
