#!/usr/bin/env python3
"""
System architecture docs.
"""
