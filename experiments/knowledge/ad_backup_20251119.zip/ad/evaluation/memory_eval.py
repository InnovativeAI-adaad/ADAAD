#!/usr/bin/env python3
"""
Memory evaluation.
"""
