#!/usr/bin/env python3
"""
External service B.
"""
