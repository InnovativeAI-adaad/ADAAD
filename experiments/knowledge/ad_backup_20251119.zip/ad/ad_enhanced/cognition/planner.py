"""
Planner is responsible for decomposing high-level goals into concrete tasks.

This simplistic planner takes a list of goal strings and returns a list of
task dictionaries. Each task dictionary specifies which tool to invoke and
which parameters to pass. In a more sophisticated implementation, the planner
might call a language model to generate sequences of actions, perform
dependency analysis, or consult external ontologies【814107018393637†L128-L170】.
"""

from __future__ import annotations

from typing import List, Dict, Any


class Planner:
    """Simple planner generating tasks from high-level goals."""

    def create_plan(self, goals: List[str]) -> List[Dict[str, Any]]:
        """Generate a plan comprising tasks for each goal.

        Args:
            goals: A list of textual goals.

        Returns:
            A list of task dictionaries. Each dictionary contains at least
            'tool' and 'parameters' keys.
        """
        plan: List[Dict[str, Any]] = []
        for goal in goals:
            # Very naive strategy: if the goal contains a mathematical
            # expression, use the calculator. If it looks like a file path,
            # use the file manager. Otherwise, perform a web search.
            goal_lower = goal.lower().strip()
            if any(ch.isdigit() for ch in goal_lower) and any(op in goal_lower for op in "+-*/"):
                plan.append({"tool": "calculator", "parameters": {"expression": goal}})
            elif goal_lower.startswith("read "):
                # Example: "read /path/to/file.txt"
                path = goal_lower.split("read ", 1)[1]
                plan.append({"tool": "file_manager", "parameters": {"operation": "read", "path": path}})
            else:
                plan.append({"tool": "search", "parameters": {"query": goal}})
        return plan