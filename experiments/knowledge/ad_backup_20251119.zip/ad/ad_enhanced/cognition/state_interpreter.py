"""
StateInterpreter converts raw observations into structured state representations
for use by the planner or decision policy. Different environments require
different interpreters: for example, interpreting sensor readings into
meaningful features. This default implementation simply returns the
observation unchanged.
"""

from __future__ import annotations

from typing import Any, Dict


class StateInterpreter:
    """Identity interpreter returning observations unchanged."""

    def interpret(self, observation: Dict[str, Any]) -> Dict[str, Any]:
        return observation