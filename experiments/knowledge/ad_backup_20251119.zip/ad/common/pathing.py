# ~/ad/common/pathing.py

from __future__ import annotations

from pathlib import Path
from typing import Optional


class PathFactory:
    """
    Enforces ADAAD's P1.0 World Isolation Invariant.

    All file access MUST come through this factory.
    No module should directly construct a filesystem path.
    """

    def __init__(self, adaad_root: Path, world_id: str):
        self.adaad_root = adaad_root.expanduser().resolve()
        self.world_id = world_id

    # ---------------------------------------------------
    # High-level world paths
    # ---------------------------------------------------
    def world_root(self) -> Path:
        return self.adaad_root / "worlds" / self.world_id

    def agents_live(self) -> Path:
        return self.world_root() / "agents" / "live"

    def agents_verified(self) -> Path:
        return self.world_root() / "agents" / "verified"

    def agents_quarantine(self) -> Path:
        return self.world_root() / "agents" / "quarantine"

    def dreams(self) -> Path:
        return self.world_root() / "dreams"

    def logs(self) -> Path:
        return self.world_root() / "logs"

    def data(self) -> Path:
        return self.world_root() / "data"

    def sandbox(self) -> Path:
        return self.world_root() / "sandbox"

    # Global (non-world) seeds directory
    def seeds_global(self) -> Path:
        return self.adaad_root / "agents" / "seeds"

    # ---------------------------------------------------
    # Safety guard: all paths remain inside adaad_root
    # ---------------------------------------------------
    def guard(self, path: Path) -> Path:
        """
        Ensure `path` stays inside ADAAD_ROOT.
        """
        resolved = path.expanduser().resolve()
        try:
            resolved.relative_to(self.adaad_root)
        except ValueError:
            raise PermissionError(f"Path escape attempt blocked: {resolved}")
        return resolved

    # ---------------------------------------------------
    # Safe open() wrapper
    # ---------------------------------------------------
    def safe_open(self, rel_path: Path, mode: str = "r", *args, **kwargs):
        """
        Open a file relative to ADAAD_ROOT with guard enforcement.
        """
        abs_path = self.guard(self.adaad_root / rel_path)
        return open(abs_path, mode, *args, **kwargs)


# ---------------------------------------------------
# Backwards-compat alias
# ---------------------------------------------------
# Old code imports `Pathing` from common.pathing; keep that working.
Pathing = PathFactory
