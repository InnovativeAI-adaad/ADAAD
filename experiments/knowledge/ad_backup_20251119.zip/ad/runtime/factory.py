# ~/ad/runtime/factory.py

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from runtime.context import RuntimeContext
from common.pathing import PathFactory

# Core components
from core.mutation.engine import MutationEngine
from core.scoring.evaluator import Evaluator
from core.dna.lineage import Lineage
from core.cryovant import Cryovant
from core.sandbox import Sandbox


@dataclass
class Factory:
    """
    Central wiring hub for a given RuntimeContext + ADAAD root.

    Provides:
      - paths: PathFactory (world-governed filesystem)
      - mutation_engine(): MutationEngine
      - scorer(): Evaluator
      - dna(): Lineage
      - cryovant(): Cryovant
      - sandbox(): Sandbox
    """

    ctx: RuntimeContext
    adaad_root: Path

    def __post_init__(self):
        # Normalize root and construct the world-local PathFactory
        self.adaad_root = self.adaad_root.expanduser().resolve()
        self.paths = PathFactory(self.adaad_root, self.ctx.world_id)

    # ---------------------------------------------------
    # Component constructors
    # ---------------------------------------------------
    def mutation_engine(self) -> MutationEngine:
        return MutationEngine(self.ctx, self.paths)

    def scorer(self) -> Evaluator:
        return Evaluator(self.ctx, self.paths)

    def dna(self) -> Lineage:
        return Lineage(self.ctx, self.paths)

    def cryovant(self) -> Cryovant:
        return Cryovant(self.ctx, self.paths)

    def sandbox(self) -> Sandbox:
        return Sandbox(self.ctx, self.paths)
