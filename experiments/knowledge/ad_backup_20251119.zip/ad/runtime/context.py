# ~/ad/runtime/context.py

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import uuid


@dataclass(frozen=True)
class RuntimeContext:
    """
    Governing execution context for ADAAD.
    Provides:
    - World isolation (P1.0)
    - Deterministic environment boundaries
    - Mutation profile governance
    - Dry-run simulation mode
    """

    world_id: str
    dry_run: bool = False
    mutation_profile: Optional[str] = "default"

    # ----- Factories -----

    @staticmethod
    def new(world_root: Path, dry_run: bool = False, profile: str = "default"):
        """
        Create a new isolated world inside world_root/<uuid>/.
        """
        wid = uuid.uuid4().hex[:12]
        world_path = world_root / wid
        world_path.mkdir(parents=True, exist_ok=True)
        return RuntimeContext(world_id=wid, dry_run=dry_run, mutation_profile=profile)

    @staticmethod
    def default():
        """
        Stable non-evolution context used during system boot.
        """
        return RuntimeContext(world_id="default", dry_run=False, mutation_profile="default")

    # ----- Helpers -----

    def is_simulation(self) -> bool:
        return self.world_id.startswith("sim-") or self.dry_run

    def is_default(self) -> bool:
        return self.world_id == "default"

    def describe(self) -> str:
        return (
            f"RuntimeContext("
            f"world_id={self.world_id}, "
            f"dry_run={self.dry_run}, "
            f"mutation_profile={self.mutation_profile}"
            f")"
        )
