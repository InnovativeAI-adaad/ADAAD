"""
Custom exceptions used across the ADAAD project.

Defining your own exception types allows for finer-grained error handling
and makes it easier to identify agent-specific issues. All agent-related
exceptions should inherit from AgentError.
"""

class AgentError(Exception):
    """Base class for exceptions raised by ADAAD agents."""


class ToolNotFoundError(AgentError):
    """Raised when an agent tries to invoke a tool that is not registered."""

    def __init__(self, tool_name: str) -> None:
        super().__init__(f"Tool '{tool_name}' not found")
        self.tool_name = tool_name