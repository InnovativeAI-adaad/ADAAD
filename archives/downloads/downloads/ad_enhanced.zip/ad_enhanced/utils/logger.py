"""
Logger utility for ADAAD agents and subsystems.

This module centralizes logging configuration. Use `get_logger` to obtain
a logger with a consistent format. The default configuration prints
timestamped messages with the logger name and level.
"""

from __future__ import annotations

import logging
import sys
from typing import Optional


_DEFAULT_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Return a configured logger for the given name.

    Logs are output to stderr with a simple formatter. Repeated calls to
    this function will return the same logger instance.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        formatter = logging.Formatter(
            fmt="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            datefmt=_DEFAULT_FORMAT,
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger