"""
BaseAgent defines the fundamental interface for all agents in the ADAAD system.

Agents follow a simple perceive–think–act loop. Subclasses should implement
concrete behaviour for these stages by overriding the abstract methods
provided here. The base class includes support for managing a task queue,
interacting with tools via a ToolRegistry, and persisting state via a
MemoryManager. A logger is available for structured logging.

This implementation is intentionally simple yet extensible. It can run on
constrained environments (e.g. Android Termux/Pydroid3) without heavy
dependencies. Developers can build autonomous or specialized agents atop
BaseAgent by overriding key methods such as `observe`, `decide`, and `act`.

References:
  - The concept of a simple agent loop with perceive/plan/act phases is
    commonly used in AI literature and agentic AI frameworks【814107018393637†L128-L170】.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Iterable

from ..utils.logger import get_logger
from ..utils.exceptions import AgentError
from ..utils.common_helpers import now_isoformat
from ..cognition.memory.memory_manager import MemoryManager
from ..cognition.decision_policy import DecisionPolicy
from ..cognition.reasoner import Reasoner
from ..cognition.planner import Planner
from .tools.tool_registry import ToolRegistry


class BaseAgent(ABC):
    """Abstract base class providing the core lifecycle for all agents.

    Attributes:
        name: Human-readable identifier for the agent.
        memory: MemoryManager providing long- and short-term storage.
        decision_policy: Policy module controlling how the agent chooses
            actions based on observations and internal state.
        reasoner: Module responsible for deriving high-level conclusions
            or explanations from observations.
        planner: Planner used to decompose goals into steps and assign tools.
        tool_registry: Registry of available tools the agent can invoke.
    """

    def __init__(
        self,
        name: str,
        memory: Optional[MemoryManager] = None,
        decision_policy: Optional[DecisionPolicy] = None,
        reasoner: Optional[Reasoner] = None,
        planner: Optional[Planner] = None,
        tool_registry: Optional[ToolRegistry] = None,
        log_level: int = logging.INFO,
    ) -> None:
        self.name = name
        self.logger = get_logger(name, level=log_level)
        self.memory = memory or MemoryManager()
        self.decision_policy = decision_policy or DecisionPolicy()
        self.reasoner = reasoner or Reasoner()
        self.planner = planner or Planner()
        self.tool_registry = tool_registry or ToolRegistry()
        # Task queue: stores tasks to be processed. A task can be any object
        # representing work; by default use a list of dictionaries.
        self._task_queue: List[Dict[str, Any]] = []

    # --- Core Lifecycle Methods ---
    @abstractmethod
    def observe(self) -> Dict[str, Any]:
        """Acquire new observations from the environment.

        Subclasses must override this method to provide domain-specific
        observation logic (e.g. reading sensors, receiving API events).
        The returned dictionary should contain raw observation data.
        """
        raise NotImplementedError

    @abstractmethod
    def decide(self, observation: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Given an observation, decide on the next task to perform.

        Subclasses should use `decision_policy` and `planner` to produce
        structured tasks. A task is typically a dict with keys like
        'tool', 'parameters', and 'goal'. If no task is produced, return None.
        """
        raise NotImplementedError

    @abstractmethod
    def act(self, task: Dict[str, Any]) -> Any:
        """Execute a given task by invoking the appropriate tool or internal logic.

        Subclasses should call `self.tool_registry.get_tool(task['tool'])` to
        retrieve the tool and then call its `execute` method with the provided
        parameters. This method should handle errors gracefully and log
        execution results.
        """
        raise NotImplementedError

    def add_task(self, task: Dict[str, Any]) -> None:
        """Add a task to the agent's task queue.

        Tasks are processed FIFO; a list structure suffices for most use cases.
        """
        self.logger.debug(f"Adding task to queue: {task}")
        self._task_queue.append(task)

    def get_next_task(self) -> Optional[Dict[str, Any]]:
        """Retrieve the next task from the queue or None if empty."""
        if not self._task_queue:
            return None
        return self._task_queue.pop(0)

    def run(self, cycles: int = 1) -> None:
        """Run the agent loop for a specified number of cycles.

        In each cycle the agent:
            1. Observes the environment.
            2. Updates its memory with the observation.
            3. Decides on a task (if any) based on the observation.
            4. Executes the decided task and records the result.

        Args:
            cycles: Number of perceive–think–act iterations to run.
        """
        for step in range(cycles):
            self.logger.debug(f"Cycle {step + 1}/{cycles} starting...")
            observation = self.observe()
            self.logger.debug(f"Observation: {observation}")
            # Persist observation to memory
            self.memory.remember("observation", observation)
            # Decide on a task
            task = self.decide(observation)
            if task is None:
                self.logger.info("No task decided; agent is idle this cycle.")
                continue
            # Enqueue and execute task
            self.add_task(task)
            next_task = self.get_next_task()
            if next_task:
                self.logger.debug(f"Executing task: {next_task}")
                try:
                    result = self.act(next_task)
                    self.memory.remember("result", result)
                    self.logger.info(f"Task result: {result}")
                except Exception as exc:
                    self.logger.exception("Error executing task: %s", exc)
                    self.memory.remember("error", str(exc))
            self.logger.debug(f"Cycle {step + 1}/{cycles} complete.")

    # --- Helper Methods ---
    def remember(self, key: str, value: Any) -> None:
        """Proxy method to store a value in memory with the given key."""
        self.memory.remember(key, value)

    def recall(self, key: str) -> Iterable[Any]:
        """Proxy method to retrieve values associated with a key from memory."""
        return self.memory.recall(key)

    def register_tool(self, tool: Any) -> None:
        """Register a tool with the agent's tool registry."""
        self.tool_registry.register_tool(tool)

    def available_tools(self) -> List[str]:
        """Return the names of all tools available to this agent."""
        return list(self.tool_registry.get_all_tools().keys())

    def __repr__(self) -> str:  # pragma: no cover - representation is trivial
        return f"{self.__class__.__name__}(name={self.name!r})"