"""
Tools package providing built-in utilities for ADAAD agents.

Each tool implements a callable interface with a name, description,
parameter schema and an execute method. Tools are registered with the
ToolRegistry and can be invoked by agents via tasks.
"""

from .calculator import CalculatorTool
from .file_manager import FileManagerTool
from .search_tool import SearchTool

__all__ = [
    "CalculatorTool",
    "FileManagerTool",
    "SearchTool",
]