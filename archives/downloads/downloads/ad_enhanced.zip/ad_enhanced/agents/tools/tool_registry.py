"""
ToolRegistry manages the registration and retrieval of tools available to
agents. Tools are simple classes that implement an `execute` method and
optionally provide metadata such as name, description and parameter schema.

The registry maintains a mapping of tool names to tool instances. Register
tools at startup so that agents can discover and execute them. This design
is inspired by common agent frameworks where a central tool registry is used
to organise capabilities【814107018393637†L128-L169】.
"""

from __future__ import annotations

from typing import Dict, Optional, Iterable, Any, Type


class ToolRegistry:
    """Central registry for all tools available to agents."""

    def __init__(self) -> None:
        # Use a dict keyed by tool name to store tool instances
        self._tools: Dict[str, Any] = {}

    def register_tool(self, tool: Any) -> None:
        """Register a tool instance with the registry.

        Args:
            tool: An object implementing an `execute` method and optionally
                `name`, `description`, and `parameters` attributes.
        """
        name = getattr(tool, "name", None)
        if callable(name):
            name = name()
        if not name:
            raise ValueError("Tool must define a name() method or name property")
        self._tools[name] = tool

    def get_tool(self, tool_name: str) -> Optional[Any]:
        """Retrieve a tool by its name or return None if not found."""
        return self._tools.get(tool_name)

    def get_all_tools(self) -> Dict[str, Any]:
        """Return a dictionary of all registered tools."""
        return dict(self._tools)

    def register_tools_from_module(self, module: Any) -> None:
        """Register all tool classes defined in a module.

        Classes will be instantiated without arguments. They must implement
        a `name()` method returning a unique tool name.
        """
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, type):
                # A class: instantiate and register if it has a name
                try:
                    instance = attr()
                    self.register_tool(instance)
                except Exception:
                    # Skip classes that cannot be instantiated without args
                    continue