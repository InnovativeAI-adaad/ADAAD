"""
Calculator tool for evaluating simple arithmetic expressions.

This tool provides the ability for agents to perform basic calculations
without relying on an external language model. It accepts a mathematical
expression as a string and returns the evaluated result. Only safe
operations are allowed; the input is parsed using the Python ast module
to prevent execution of arbitrary code.
"""

from __future__ import annotations

import ast
import operator as op
from typing import Any, Dict


class CalculatorTool:
    """Agent-callable calculator tool."""

    def name(self) -> str:
        return "calculator"

    def description(self) -> str:
        return "Evaluate basic arithmetic expressions."

    def parameters(self) -> Dict[str, Any]:
        return {
            "expression": {
                "type": "string",
                "description": "A mathematical expression to evaluate"
            }
        }

    def execute(self, expression: str) -> Dict[str, Any]:
        """Safely evaluate an arithmetic expression.

        Only supports numbers and basic operators (+, -, *, /, %, **).
        Returns a dictionary with the result or an error message.
        """
        try:
            result = self._safe_eval(expression)
            return {"result": result}
        except Exception as exc:
            return {"error": str(exc)}

    # --- Internal Methods ---
    def _safe_eval(self, expr: str) -> Any:
        """Evaluate an expression securely using ast."""
        node = ast.parse(expr, mode="eval")
        return self._eval_node(node.body)

    def _eval_node(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Num):
            return node.n
        if isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            operator_type = type(node.op)
            operators = {
                ast.Add: op.add,
                ast.Sub: op.sub,
                ast.Mult: op.mul,
                ast.Div: op.truediv,
                ast.Mod: op.mod,
                ast.Pow: op.pow,
            }
            if operator_type not in operators:
                raise ValueError(f"Unsupported operator: {operator_type}")
            return operators[operator_type](left, right)
        if isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand)
            if isinstance(node.op, ast.UAdd):
                return +operand
            if isinstance(node.op, ast.USub):
                return -operand
            raise ValueError(f"Unsupported unary operator: {type(node.op)}")
        raise ValueError(f"Unsupported expression: {ast.dump(node)}")