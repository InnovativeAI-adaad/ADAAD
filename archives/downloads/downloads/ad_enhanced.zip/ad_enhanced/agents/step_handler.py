"""
StepHandler encapsulates a single iteration of an agent's loop. It provides
a hook for performing additional logic around each step such as logging,
profiling, or interrupt handling. It can be used by orchestrators or
agents themselves to customize step-level behaviour without modifying
the agent's core logic.
"""

from __future__ import annotations

from typing import Callable, Any


class StepHandler:
    """Call a user-defined function around each step of an agent's loop."""

    def __init__(self, before_step: Callable[[int], None] | None = None,
                 after_step: Callable[[int, Any], None] | None = None) -> None:
        self.before_step = before_step
        self.after_step = after_step

    def handle(self, step: int, step_fn: Callable[[], Any]) -> Any:
        """Execute a step with optional hooks.

        Args:
            step: The step index (starting from 0).
            step_fn: A function representing the step's execution. It is
                expected to return a result.

        Returns:
            The result of the step function.
        """
        if self.before_step:
            self.before_step(step)
        result = step_fn()
        if self.after_step:
            self.after_step(step, result)
        return result