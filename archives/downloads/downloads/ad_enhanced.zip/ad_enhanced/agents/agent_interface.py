"""
AgentInterface defines the communication contract for agents in the ADAAD
ecosystem.

Agents interact with external systems (e.g. APIs, UIs, other agents) via
interfaces. An interface may provide synchronous request/response patterns,
asynchronous message handling, or streaming interactions. This base class
provides a minimal synchronous interface using call/response semantics.

Developers may extend this class to support WebSocket-based streaming,
REST/HTTP endpoints, or other protocols. The interface decouples
communication details from the agent's reasoning logic, enabling agents to
focus on high-level decisions.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict


class AgentInterface(ABC):
    """Abstract base class for agent communication interfaces."""

    @abstractmethod
    def send(self, message: Dict[str, Any]) -> None:
        """Send a message to the external system.

        Args:
            message: Structured data describing what the agent wishes to
                communicate. The concrete implementation will determine how
                messages are serialized and transmitted.
        """
        raise NotImplementedError

    @abstractmethod
    def receive(self) -> Dict[str, Any]:
        """Receive a message from the external system.

        Returns:
            A structured message. Implementations should block until a message
            is available or time out gracefully.
        """
        raise NotImplementedError

    def request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Convenience method performing a send followed by a receive.

        For interfaces that support synchronous request/response, this method
        provides a simple way to send a request and wait for a response.
        """
        self.send(payload)
        return self.receive()