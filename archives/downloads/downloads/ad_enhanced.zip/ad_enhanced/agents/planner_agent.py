"""
PlannerAgent implements a specialized agent that focuses primarily on
generating plans given a high-level goal. It extends BaseAgent and delegates
planning to the cognition planner module while deferring execution to other
components. Planner agents are useful in multi-agent workflows where one
agent produces a sequence of tasks and another carries them out.
"""

from __future__ import annotations

from typing import Dict, Any, Optional

from .base_agent import BaseAgent


class PlannerAgent(BaseAgent):
    """Agent that produces plans and returns them as tasks without executing."""

    def observe(self) -> Dict[str, Any]:
        """Observe the environment for planning. By default returns an empty
        observation. In a realistic scenario, the planner could retrieve goal
        descriptions or contextual data.
        """
        # For demonstration, we assume the goal is stored in memory under
        # the key 'goal'. Derived planners may override this method to
        # implement custom observation logic.
        goals = list(self.memory.recall("goal"))
        return {"goals": goals}

    def decide(self, observation: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create a plan given the observed goals.

        The planning logic is delegated to the planner module. The produced
        plan is stored in memory and returned as a task dictionary with the
        tool set to 'plan' so that downstream agents can pick it up.
        """
        goals = observation.get("goals", [])
        if not goals:
            self.logger.debug("No goals provided; nothing to plan.")
            return None
        plan = self.planner.create_plan(goals)
        self.memory.remember("plan", plan)
        return {"tool": "plan", "parameters": {"plan": plan}, "goal": goals}

    def act(self, task: Dict[str, Any]) -> Any:
        """PlannerAgent does not execute plans; it returns them directly."""
        return task["parameters"]["plan"]