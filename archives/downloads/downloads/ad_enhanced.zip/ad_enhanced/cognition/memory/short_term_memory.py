"""
ShortTermMemory stores recent observations and results for quick recall.

The storage capacity is limited and items are removed on a first-in,
first-out basis when the limit is reached. Use this class to maintain
context for the current conversation or task. If capacity is None, the
memory grows without bound (not recommended for long-running agents).
"""

from __future__ import annotations

from collections import deque
from typing import Any, Dict, Iterable, Optional, List


class ShortTermMemory:
    """Finite-capacity storage for recent items."""

    def __init__(self, capacity: Optional[int] = 100) -> None:
        self.capacity = capacity
        self._store: Dict[str, deque] = {}

    def remember(self, key: str, value: Any) -> None:
        q = self._store.setdefault(key, deque())
        q.append(value)
        if self.capacity is not None and len(q) > self.capacity:
            q.popleft()

    def recall(self, key: str) -> Iterable[Any]:
        return list(self._store.get(key, []))

    def forget(self, key: str) -> None:
        self._store.pop(key, None)

    def clear(self) -> None:
        self._store.clear()