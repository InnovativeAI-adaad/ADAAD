"""
MemoryManager orchestrates long-term and short-term memories for agents.

It provides a unified interface for storing and retrieving data. By default,
data is recorded in both long-term and short-term memories, but call
parameters can limit the storage to either. Use the short-term memory for
context-sensitive operations and the long-term memory for persistent
knowledge accumulation.
"""

from __future__ import annotations

from typing import Any, Iterable, Optional

from .long_term_memory import LongTermMemory
from .short_term_memory import ShortTermMemory


class MemoryManager:
    """Combine long-term and short-term memory storage."""

    def __init__(self, short_term_capacity: Optional[int] = 100) -> None:
        self.long_term = LongTermMemory()
        self.short_term = ShortTermMemory(capacity=short_term_capacity)

    def remember(self, key: str, value: Any, *, long_term: bool = True, short_term: bool = True) -> None:
        """Store a value in memory.

        Args:
            key: A label for the stored value.
            value: Data to store.
            long_term: Whether to store in long-term memory.
            short_term: Whether to store in short-term memory.
        """
        if long_term:
            self.long_term.remember(key, value)
        if short_term:
            self.short_term.remember(key, value)

    def recall(self, key: str, *, long_term: bool = True, short_term: bool = True) -> Iterable[Any]:
        """Retrieve stored values for the given key."""
        results = []
        if short_term:
            results.extend(self.short_term.recall(key))
        if long_term:
            results.extend(self.long_term.recall(key))
        return results

    def forget(self, key: str, *, long_term: bool = True, short_term: bool = True) -> None:
        """Remove all stored values for the given key."""
        if long_term:
            self.long_term.forget(key)
        if short_term:
            self.short_term.forget(key)

    def clear(self) -> None:
        """Clear all memories."""
        self.long_term.clear()
        self.short_term.clear()