"""
LongTermMemory provides persistent storage for knowledge and experiences
accumulated by an agent. Data persists across sessions if serialized by
the caller. This implementation stores items in memory indefinitely and
supports multi-valued keys (multiple values per key). Each call to
`remember` appends a new entry to the list associated with the key.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List


class LongTermMemory:
    """Simple in-memory key-value store for long-term memory."""

    def __init__(self) -> None:
        self._store: Dict[str, List[Any]] = {}

    def remember(self, key: str, value: Any) -> None:
        self._store.setdefault(key, []).append(value)

    def recall(self, key: str) -> Iterable[Any]:
        return list(self._store.get(key, []))

    def forget(self, key: str) -> None:
        self._store.pop(key, None)

    def clear(self) -> None:
        self._store.clear()