"""
DecisionPolicy encapsulates heuristics for selecting tasks or actions.

Given a set of observations and potential tasks produced by a planner,
the policy decides which task to perform next. This simple implementation
selects tasks in the order they are provided but can be extended with
scoring, prioritization, or learned policies. For example, reinforcement
learning could be used to adapt the decision-making process over time.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class DecisionPolicy:
    """Basic decision policy selecting the first available task."""

    def select_task(self, tasks: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Return the highest priority task from the list of tasks.

        Currently, tasks are assumed to be pre-ordered by priority. Override
        this method to implement custom prioritization or filtering. If the
        list is empty, returns None.
        """
        return tasks[0] if tasks else None