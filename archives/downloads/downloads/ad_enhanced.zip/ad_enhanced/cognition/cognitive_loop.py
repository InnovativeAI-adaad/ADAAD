"""
The cognitive loop coordinates the perception, reasoning, planning, and action
phases of an agent. While BaseAgent includes its own loop implementation,
this module provides an alternative functional interface that can be used
independently or embedded in custom orchestrators. It accepts callback
functions for each phase and manages the flow between them.
"""

from __future__ import annotations

from typing import Callable, Any, Dict, Optional


def run_cognitive_cycle(
    observe_fn: Callable[[], Dict[str, Any]],
    decide_fn: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]],
    act_fn: Callable[[Dict[str, Any]], Any],
    memory_fn: Callable[[str, Any], None],
    cycles: int = 1,
) -> None:
    """Execute a cognitive cycle defined by the provided callback functions.

    Args:
        observe_fn: Function returning a new observation.
        decide_fn: Function deciding what task to perform given an observation.
        act_fn: Function executing the task and returning a result.
        memory_fn: Function used to record observations and results.
        cycles: Number of iterations to run.
    """
    for i in range(cycles):
        observation = observe_fn()
        memory_fn("observation", observation)
        task = decide_fn(observation)
        if task is None:
            continue
        result = act_fn(task)
        memory_fn("result", result)